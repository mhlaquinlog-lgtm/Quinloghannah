import java.util.Scanner;

public class AssignVolunteer5
{
    public static void main(String[] args)
    {
        final int CLOTHING_CODE = 1;
        final int FURNITURE_CODE = 2;
        final int ELECTRONICS_CODE = 3;
        final int OTHER_CODE = 4;

        String volunteer;
        int donationType;

        Scanner input = new Scanner(System.in);

        System.out.print("Enter donation type code (1-4): ");
        donationType = input.nextInt();

        while(donationType < CLOTHING_CODE || donationType > OTHER_CODE)
        {
            System.out.println("You entered " + donationType + " which is not a valid donation type");
            System.out.print("Please enter a value between " + CLOTHING_CODE + " and " + OTHER_CODE + "... ");
            System.out.print("Enter an integer... ");
            donationType = input.nextInt();
        }

        switch(donationType)
        {
            case CLOTHING_CODE:
                volunteer = "Ann";
                break;

            case FURNITURE_CODE:
                volunteer = "Bill";
                break;

            case ELECTRONICS_CODE:
                volunteer = "Cathy";
                break;

            case OTHER_CODE:
                volunteer = "Dan";
                break;

            default:
                volunteer = "Invalid";
        }

        System.out.println("The volunteer who will price this item is " + volunteer);
    }
}