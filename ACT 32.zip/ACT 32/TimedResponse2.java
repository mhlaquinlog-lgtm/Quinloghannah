import javax.swing.JOptionPane;
import java.time.*;

public class TimedResponse2
{
    public static void main(String[] args)
    {
        LocalDateTime time1, time2;
        long difference;

        time1 = LocalDateTime.now();

        JOptionPane.showConfirmDialog(null, "Is stealing ever justified?");

        time2 = LocalDateTime.now();

        difference = Duration.between(time1, time2).getSeconds();

        JOptionPane.showMessageDialog(null,
                "It took " + difference +
                " seconds for you to answer");
    }
}