public class UndergraduateStudent extends Student {
    public UndergraduateStudent(int id, String lastName) {
        super(id, lastName);
        setTuition();
    }

    @Override
    public void setTuition() { setTuitionField(4000 * 2); } // 2 semesters
}
