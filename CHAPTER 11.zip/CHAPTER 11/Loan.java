public abstract class Loan implements LoanConstants {
    private int loanNumber;
    private String customerLastName;
    private double loanAmount;
    protected double interestRate;
    private int term;

    public Loan(int loanNumber, String lastName, double amount, int term) {
        this.loanNumber = loanNumber;
        this.customerLastName = lastName;
        this.loanAmount = (amount > MAX_LOAN_AMOUNT) ? MAX_LOAN_AMOUNT : amount;
        if (term != SHORT_TERM && term != MEDIUM_TERM && term != LONG_TERM)
            this.term = SHORT_TERM;
        else
            this.term = term;
    }

    public int getLoanNumber() { return loanNumber; }
    public String getLastName() { return customerLastName; }
    public double getLoanAmount() { return loanAmount; }
    public double getInterestRate() { return interestRate; }
    public int getTerm() { return term; }

    public double getTotalOwed() {
        return loanAmount + (loanAmount * interestRate * term);
    }

    @Override
    public String toString() {
        return String.format("Loan #%d | Customer: %s | Amount: $%.2f | Rate: %.2f%% | Term: %d yr | Total Owed: $%.2f",
            loanNumber, customerLastName, loanAmount,
            interestRate * 100, term, getTotalOwed());
    }
}
