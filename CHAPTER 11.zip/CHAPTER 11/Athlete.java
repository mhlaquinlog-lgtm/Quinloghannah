public class Athlete implements Runner {
    @Override
    public void run() { System.out.println("An athlete runs for speed and endurance."); }
}
