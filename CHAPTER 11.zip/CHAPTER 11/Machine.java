public class Machine implements Runner {
    @Override
    public void run() { System.out.println("A machine runs on power and mechanics."); }
}
