public abstract class Insurance {
    private String type;
    private double monthlyPrice;

    public Insurance(String type) { this.type = type; }

    public String getType() { return type; }
    public double getMonthlyPrice() { return monthlyPrice; }
    protected void setPriceField(double p) { this.monthlyPrice = p; }

    public abstract void setCost();
    public abstract void display();
}
