public class DomesticDivision extends Division {
    private String state;

    public DomesticDivision(String name, int acct, String state) {
        super(name, acct);
        this.state = state;
    }

    @Override
    public void display() {
        System.out.println("Domestic Division: " + getName()
            + " | Account: " + getAccountNumber() + " | State: " + state);
    }
}
