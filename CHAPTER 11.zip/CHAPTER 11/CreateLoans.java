import java.util.Scanner;

public class CreateLoans {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Loan[] loans = new Loan[5];

        System.out.print("Enter current prime interest rate (%): ");
        double prime = Double.parseDouble(sc.nextLine());

        for (int i = 0; i < 5; i++) {
            System.out.println("\n--- Loan " + (i + 1) + " ---");
            System.out.print("Loan type (B=Business, P=Personal): ");
            String type = sc.nextLine().trim().toUpperCase();
            System.out.print("Loan number: ");
            int num = Integer.parseInt(sc.nextLine());
            System.out.print("Customer last name: ");
            String name = sc.nextLine();
            System.out.print("Loan amount: $");
            double amount = Double.parseDouble(sc.nextLine());
            System.out.print("Term (1, 3, or 5 years): ");
            int term = Integer.parseInt(sc.nextLine());

            if (type.equals("B"))
                loans[i] = new BusinessLoan(num, name, amount, term, prime);
            else
                loans[i] = new PersonalLoan(num, name, amount, term, prime);
        }

        System.out.println("\n=== " + LoanConstants.COMPANY_NAME + " ===");
        for (Loan l : loans) System.out.println(l);
        sc.close();
    }
}
