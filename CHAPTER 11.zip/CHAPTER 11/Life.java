public class Life extends Insurance {
    public Life() {
        super("Life");
        setCost();
    }

    @Override
    public void setCost() { setPriceField(36.00); }

    @Override
    public void display() {
        System.out.println("Insurance Type: " + getType() + " | Monthly Cost: $" + getMonthlyPrice());
    }
}
