public class OnlineNewspaperSubscription extends NewspaperSubscription {
    @Override
    public void setAddress(String address) {
        if (!address.contains("@")) {
            System.out.println("Error: Online address must contain '@'.");
            setRate(0);
        } else {
            setAddressField(address);
            setRate(9.00);
        }
    }
}
