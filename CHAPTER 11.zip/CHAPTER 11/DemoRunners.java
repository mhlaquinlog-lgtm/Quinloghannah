public class DemoRunners {
    public static void main(String[] args) {
        Runner machine   = new Machine();
        Runner athlete   = new Athlete();
        Runner candidate = new PoliticalCandidate();
        machine.run();
        athlete.run();
        candidate.run();
    }
}
