public class DemoPhoneCalls {
    public static void main(String[] args) {
        PhoneCall in = new IncomingPhoneCall("555-1234");
        PhoneCall out = new OutgoingPhoneCall("555-5678", 10);
        in.displayCall();
        out.displayCall();
    }
}
