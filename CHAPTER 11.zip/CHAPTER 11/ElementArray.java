public class ElementArray {
    public static void main(String[] args) {
        Element[] elements = {
            new MetalElement("Fe", 26, 55.85),
            new MetalElement("Au", 79, 196.97),
            new NonMetalElement("C", 6, 12.01),
            new NonMetalElement("O", 8, 15.99),
            new NonMetalElement("N", 7, 14.01)
        };
        for (Element e : elements) e.describeElement();
    }
}
