public class PersonalLoan extends Loan {
    public PersonalLoan(int num, String lastName, double amount, int term, double primeRate) {
        super(num, lastName, amount, term);
        this.interestRate = (primeRate + 2.0) / 100.0;
    }
}
