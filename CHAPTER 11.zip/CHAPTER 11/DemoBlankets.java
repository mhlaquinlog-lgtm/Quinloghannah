public class DemoBlankets {
    public static void main(String[] args) {
        Blanket b = new Blanket();
        System.out.println("Default: " + b);

        b.setSize("King");
        b.setColor("blue");
        b.setMaterial("cashmere");
        System.out.println("Custom Blanket: " + b);

        ElectricBlanket eb = new ElectricBlanket();
        eb.setSize("Queen");
        eb.setMaterial("wool");
        eb.setHeatSettings(3);
        eb.setAutoShutoff(true);
        System.out.println("Electric Blanket: " + eb);
    }
}
