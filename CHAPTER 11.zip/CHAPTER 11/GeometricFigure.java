public abstract class GeometricFigure {
    protected double height;
    protected double width;
    protected String figureType;
    protected double area;

    public abstract void calculateArea();
    public double getArea() { return area; }
    public String getFigureType() { return figureType; }
    public double getHeight() { return height; }
    public double getWidth() { return width; }
}
