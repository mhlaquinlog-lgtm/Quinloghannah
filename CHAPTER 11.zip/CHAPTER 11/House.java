package com.course.buildings;

public class House extends Building {
    private int bedrooms;
    private double baths;

    public House(double squareFootage, int stories, int bedrooms, double baths) {
        super(squareFootage, stories);
        this.bedrooms = bedrooms;
        this.baths = baths;
    }

    public int getBedrooms() { return bedrooms; }
    public double getBaths() { return baths; }
    public void setBedrooms(int b) { this.bedrooms = b; }
    public void setBaths(double b) { this.baths = b; }
}
