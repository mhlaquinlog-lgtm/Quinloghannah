public class ElectricBlanket extends Blanket {
    private int heatSettings;
    private boolean autoShutoff;
    private static final double SHUTOFF_PREMIUM = 5.75;

    public ElectricBlanket() {
        super();
        heatSettings = 1;
        autoShutoff = false;
    }

    public int getHeatSettings() { return heatSettings; }
    public boolean hasAutoShutoff() { return autoShutoff; }

    public void setHeatSettings(int settings) {
        if (settings < 1 || settings > 5) {
            System.out.println("Invalid setting. Using default of 1.");
            heatSettings = 1;
        } else {
            heatSettings = settings;
        }
    }

    public void setAutoShutoff(boolean shutoff) {
        this.autoShutoff = shutoff;
    }

    @Override
    public String toString() {
        double totalPrice = price + (autoShutoff ? SHUTOFF_PREMIUM : 0);
        return super.toString()
            + " | Heat settings: " + heatSettings
            + " | Auto shutoff: " + autoShutoff
            + " | Total: $" + String.format("%.2f", totalPrice);
    }
}
