public class UseGeometric {
    public static void main(String[] args) {
        GeometricFigure[] figures = {
            new Square(5.0),
            new Square(8.0),
            new Triangle(6.0, 4.0),
            new Triangle(10.0, 3.0)
        };
        for (GeometricFigure f : figures)
            System.out.println(f.getFigureType() + " | Area: " + f.getArea());
    }
}
