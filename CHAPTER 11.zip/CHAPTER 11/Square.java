public class Square extends GeometricFigure {
    public Square(double side) {
        this.height = side;
        this.width = side;
        this.figureType = "Square";
        calculateArea();
    }

    @Override
    public void calculateArea() { area = height * width; }
}
