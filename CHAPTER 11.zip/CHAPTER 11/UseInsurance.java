import java.util.Scanner;

public class UseInsurance {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter insurance type (Life/Health): ");
        String type = sc.nextLine().trim();
        Insurance policy;
        if (type.equalsIgnoreCase("Life")) {
            policy = new Life();
        } else if (type.equalsIgnoreCase("Health")) {
            policy = new Health();
        } else {
            System.out.println("Invalid insurance type entered.");
            sc.close();
            return;
        }
        policy.display();
        sc.close();
    }
}
