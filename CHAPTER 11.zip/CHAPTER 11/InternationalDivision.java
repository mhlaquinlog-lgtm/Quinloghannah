public class InternationalDivision extends Division {
    private String country;
    private String language;

    public InternationalDivision(String name, int acct, String country, String language) {
        super(name, acct);
        this.country = country;
        this.language = language;
    }

    @Override
    public void display() {
        System.out.println("International Division: " + getName()
            + " | Account: " + getAccountNumber()
            + " | Country: " + country + " | Language: " + language);
    }
}
