public class GraduateStudent extends Student {
    public GraduateStudent(int id, String lastName) {
        super(id, lastName);
        setTuition();
    }

    @Override
    public void setTuition() { setTuitionField(6000 * 2); }
}
