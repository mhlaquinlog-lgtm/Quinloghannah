public class NonMetalElement extends Element {
    public NonMetalElement(String symbol, int atomicNumber, double atomicWeight) {
        super(symbol, atomicNumber, atomicWeight);
    }

    @Override
    public void describeElement() {
        System.out.println("NonMetal | " + getSymbol()
            + " | Atomic #: " + getAtomicNumber()
            + " | Weight: " + getAtomicWeight()
            + " | Nonmetals are poor conductors of electricity.");
    }
}
