public class UseBook {
    public static void main(String[] args) {
        Fiction f = new Fiction("The Great Gatsby");
        NonFiction nf = new NonFiction("Sapiens");
        System.out.println("Fiction: " + f.getTitle() + " - $" + f.getPrice());
        System.out.println("NonFiction: " + nf.getTitle() + " - $" + nf.getPrice());
    }
}
