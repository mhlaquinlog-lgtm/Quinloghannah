public class MetalElement extends Element {
    public MetalElement(String symbol, int atomicNumber, double atomicWeight) {
        super(symbol, atomicNumber, atomicWeight);
    }

    @Override
    public void describeElement() {
        System.out.println("Metal | " + getSymbol()
            + " | Atomic #: " + getAtomicNumber()
            + " | Weight: " + getAtomicWeight()
            + " | Metals are good conductors of electricity.");
    }
}
