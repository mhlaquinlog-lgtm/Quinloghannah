public class PhysicalNewspaperSubscription extends NewspaperSubscription {
    @Override
    public void setAddress(String address) {
        boolean hasDigit = address.chars().anyMatch(Character::isDigit);
        if (!hasDigit) {
            System.out.println("Error: Physical address must contain a digit.");
            setRate(0);
        } else {
            setAddressField(address);
            setRate(15.00);
        }
    }
}
