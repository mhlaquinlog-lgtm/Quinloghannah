import java.util.Objects;

public class Participant {
    private String name;
    private int age;
    private String address;

    public Participant(String name, int age, String address) {
        this.name = name;
        this.age = age;
        this.address = address;
    }

    @Override
    public String toString() {
        return name + " (age " + age + ") - " + address;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Participant)) return false;
        Participant other = (Participant) obj;
        return name.equals(other.name) && age == other.age && address.equals(other.address);
    }

    @Override
    public int hashCode() { return Objects.hash(name, age, address); }
}
