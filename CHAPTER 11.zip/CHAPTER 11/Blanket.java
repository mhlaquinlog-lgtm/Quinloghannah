public class Blanket {
    private String size;
    private String color;
    private String material;
    protected double price;

    private static final double BASE_PRICE = 30.00;

    public Blanket() {
        resetDefaults();
    }

    protected void resetDefaults() {
        size = "Twin"; color = "white"; material = "cotton"; price = BASE_PRICE;
    }

    public void setSize(String size) {
        double baseForSize;
        switch (size.toLowerCase()) {
            case "twin":   baseForSize = BASE_PRICE; break;
            case "double": baseForSize = BASE_PRICE + 10; break;
            case "queen":  baseForSize = BASE_PRICE + 25; break;
            case "king":   baseForSize = BASE_PRICE + 40; break;
            default:
                System.out.println("Invalid size. Resetting to defaults.");
                resetDefaults(); return;
        }
        this.size = size;
        // reapply material surcharge on top of new size base
        double surcharge = 0;
        if (material.equalsIgnoreCase("wool")) surcharge = 20;
        else if (material.equalsIgnoreCase("cashmere")) surcharge = 45;
        price = baseForSize + surcharge;
    }

    public void setColor(String color) { this.color = color; }

    public void setMaterial(String material) {
        double baseForSize;
        switch (size.toLowerCase()) {
            case "double": baseForSize = BASE_PRICE + 10; break;
            case "queen":  baseForSize = BASE_PRICE + 25; break;
            case "king":   baseForSize = BASE_PRICE + 40; break;
            default:       baseForSize = BASE_PRICE;
        }
        switch (material.toLowerCase()) {
            case "cotton":   this.material = material; price = baseForSize; break;
            case "wool":     this.material = material; price = baseForSize + 20; break;
            case "cashmere": this.material = material; price = baseForSize + 45; break;
            default:
                System.out.println("Invalid material. Resetting to defaults.");
                resetDefaults();
        }
    }

    public String getSize() { return size; }
    public String getColor() { return color; }
    public String getMaterial() { return material; }
    public double getPrice() { return price; }

    @Override
    public String toString() {
        return size + " " + color + " " + material + " blanket - $" + String.format("%.2f", price);
    }
}
