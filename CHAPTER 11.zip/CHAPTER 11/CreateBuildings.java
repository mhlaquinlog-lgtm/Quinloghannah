import com.course.buildings.*;

public class CreateBuildings {
    public static void main(String[] args) {
        House h = new House(2200, 2, 4, 2.5);
        School s = new School(15000, 3, 40, "Elementary");

        System.out.println("House: " + h.getSquareFootage() + " sqft, "
            + h.getStories() + " stories, "
            + h.getBedrooms() + " bedrooms, "
            + h.getBaths() + " baths");

        System.out.println("School: " + s.getSquareFootage() + " sqft, "
            + s.getStories() + " stories, "
            + s.getClassrooms() + " classrooms, "
            + s.getGradeLevel());
    }
}
