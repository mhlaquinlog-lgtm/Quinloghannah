public class PhoneCallArray {
    public static void main(String[] args) {
        PhoneCall[] calls = new PhoneCall[10];
        calls[0] = new IncomingPhoneCall("555-0001");
        calls[1] = new OutgoingPhoneCall("555-0002", 5.0);
        calls[2] = new IncomingPhoneCall("555-0003");
        calls[3] = new OutgoingPhoneCall("555-0004", 12.5);
        calls[4] = new IncomingPhoneCall("555-0005");
        calls[5] = new OutgoingPhoneCall("555-0006", 3.0);
        calls[6] = new IncomingPhoneCall("555-0007");
        calls[7] = new OutgoingPhoneCall("555-0008", 20.0);
        calls[8] = new IncomingPhoneCall("555-0009");
        calls[9] = new OutgoingPhoneCall("555-0010", 7.5);

        for (PhoneCall c : calls) c.displayCall();
    }
}
