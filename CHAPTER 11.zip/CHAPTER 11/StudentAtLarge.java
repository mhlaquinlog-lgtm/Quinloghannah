public class StudentAtLarge extends Student {
    public StudentAtLarge(int id, String lastName) {
        super(id, lastName);
        setTuition();
    }

    @Override
    public void setTuition() { setTuitionField(2000 * 2); }
}
