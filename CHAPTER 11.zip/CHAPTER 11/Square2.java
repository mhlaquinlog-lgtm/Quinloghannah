public class Square2 extends GeometricFigure implements SidedObject {
    public Square2(double side) {
        this.height = side;
        this.width = side;
        this.figureType = "Square";
        calculateArea();
    }

    @Override
    public void calculateArea() { area = height * width; }

    @Override
    public void displaySides() { System.out.println("A square has 4 sides."); }
}
