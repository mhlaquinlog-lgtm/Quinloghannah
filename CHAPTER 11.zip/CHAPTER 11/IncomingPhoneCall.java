public class IncomingPhoneCall extends PhoneCall {
    private static final double RATE = 0.02;
    private String number;

    public IncomingPhoneCall(String phoneNumber) {
        super(phoneNumber);
        this.number = phoneNumber;
        setPrice(RATE);
    }

    @Override public String getPhoneNumber() { return number; }
    @Override public double getPrice() { return RATE; }

    @Override
    public void displayCall() {
        System.out.println("Incoming Call | Phone: " + number
            + " | Rate: $" + RATE + " | Price: $" + RATE);
    }
}
