public abstract class Student {
    private int id;
    private String lastName;
    private double annualTuition;

    public Student(int id, String lastName) {
        this.id = id;
        this.lastName = lastName;
    }

    public int getId() { return id; }
    public String getLastName() { return lastName; }
    public double getAnnualTuition() { return annualTuition; }
    public void setId(int id) { this.id = id; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    protected void setTuitionField(double t) { this.annualTuition = t; }
    public abstract void setTuition();
}
