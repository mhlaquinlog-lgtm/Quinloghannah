public class OutgoingPhoneCall extends PhoneCall {
    private static final double RATE_PER_MIN = 0.04;
    private String number;
    private double minutes;

    public OutgoingPhoneCall(String phoneNumber, double minutes) {
        super(phoneNumber);
        this.number = phoneNumber;
        this.minutes = minutes;
        setPrice(RATE_PER_MIN * minutes);
    }

    @Override public String getPhoneNumber() { return number; }
    @Override public double getPrice() { return RATE_PER_MIN * minutes; }

    @Override
    public void displayCall() {
        System.out.printf("Outgoing Call | Phone: %s | Rate: $%.2f/min | Minutes: %.1f | Total: $%.2f%n",
            number, RATE_PER_MIN, minutes, getPrice());
    }
}
