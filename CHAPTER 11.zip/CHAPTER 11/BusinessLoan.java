public class BusinessLoan extends Loan {
    public BusinessLoan(int num, String lastName, double amount, int term, double primeRate) {
        super(num, lastName, amount, term);
        this.interestRate = (primeRate + 1.0) / 100.0;
    }
}
