public abstract class NewspaperSubscription {
    private String name;
    private String address;
    private double rate;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getAddress() { return address; }
    public double getRate() { return rate; }
    protected void setAddressField(String addr) { this.address = addr; }
    protected void setRate(double rate) { this.rate = rate; }
    public abstract void setAddress(String address);
}
