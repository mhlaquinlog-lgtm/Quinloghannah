public class BookArray {
    public static void main(String[] args) {
        Book[] books = new Book[10];
        books[0] = new Fiction("Harry Potter");
        books[1] = new NonFiction("Brief History of Time");
        books[2] = new Fiction("1984");
        books[3] = new NonFiction("Thinking Fast and Slow");
        books[4] = new Fiction("To Kill a Mockingbird");
        books[5] = new NonFiction("Cosmos");
        books[6] = new Fiction("Pride and Prejudice");
        books[7] = new NonFiction("Guns Germs and Steel");
        books[8] = new Fiction("The Hobbit");
        books[9] = new NonFiction("A Short History of Nearly Everything");

        for (int i = 0; i < books.length; i++) {
            System.out.println((i + 1) + ". " + books[i].getTitle()
                + " [" + books[i].getClass().getSimpleName() + "] - $" + books[i].getPrice());
        }
    }
}
