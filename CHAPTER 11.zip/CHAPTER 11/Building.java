package com.course.buildings;

public class Building {
    private double squareFootage;
    private int stories;

    public Building(double squareFootage, int stories) {
        this.squareFootage = squareFootage;
        this.stories = stories;
    }

    public double getSquareFootage() { return squareFootage; }
    public int getStories() { return stories; }
    public void setSquareFootage(double sqft) { this.squareFootage = sqft; }
    public void setStories(int stories) { this.stories = stories; }
}
