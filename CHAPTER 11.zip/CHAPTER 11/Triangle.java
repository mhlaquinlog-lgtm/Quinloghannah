public class Triangle extends GeometricFigure {
    public Triangle(double base, double height) {
        this.width = base;
        this.height = height;
        this.figureType = "Triangle";
        calculateArea();
    }

    @Override
    public void calculateArea() { area = 0.5 * width * height; }
}
