public class StudentDemo {
    public static void main(String[] args) {
        Student[] students = {
            new UndergraduateStudent(1, "Smith"),
            new UndergraduateStudent(2, "Jones"),
            new GraduateStudent(3, "Brown"),
            new GraduateStudent(4, "Davis"),
            new StudentAtLarge(5, "Wilson"),
            new StudentAtLarge(6, "Taylor")
        };
        for (Student s : students) {
            System.out.println("ID: " + s.getId()
                + " | Name: " + s.getLastName()
                + " | Type: " + s.getClass().getSimpleName()
                + " | Annual Tuition: $" + s.getAnnualTuition());
        }
    }
}
