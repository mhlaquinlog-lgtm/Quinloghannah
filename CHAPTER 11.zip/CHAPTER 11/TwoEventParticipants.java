import java.util.Scanner;

public class TwoEventParticipants {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Participant[] marathon = new Participant[8];
        Participant[] diving   = new Participant[8];

        System.out.println("=== Enter 8 Marathon Participants ===");
        for (int i = 0; i < 8; i++) {
            System.out.print("Name: ");    String name = sc.nextLine();
            System.out.print("Age: ");     int age = Integer.parseInt(sc.nextLine());
            System.out.print("Address: "); String addr = sc.nextLine();
            marathon[i] = new Participant(name, age, addr);
        }

        System.out.println("\n=== Enter 8 Diving Participants ===");
        for (int i = 0; i < 8; i++) {
            System.out.print("Name: ");    String name = sc.nextLine();
            System.out.print("Age: ");     int age = Integer.parseInt(sc.nextLine());
            System.out.print("Address: "); String addr = sc.nextLine();
            diving[i] = new Participant(name, age, addr);
        }

        System.out.println("\n=== Participants in BOTH Events ===");
        boolean found = false;
        for (Participant m : marathon)
            for (Participant d : diving)
                if (m.equals(d)) { System.out.println(m); found = true; }
        if (!found) System.out.println("No participants in both events.");
        sc.close();
    }
}
