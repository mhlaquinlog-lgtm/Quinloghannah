public class Health extends Insurance {
    public Health() {
        super("Health");
        setCost();
    }

    @Override
    public void setCost() { setPriceField(196.00); }

    @Override
    public void display() {
        System.out.println("Insurance Type: " + getType() + " | Monthly Cost: $" + getMonthlyPrice());
    }
}
