public class UseGeometric2 {
    public static void main(String[] args) {
        Square2 sq = new Square2(7.0);
        Triangle2 tr = new Triangle2(5.0, 9.0);

        System.out.println(sq.getFigureType() + " | Area: " + sq.getArea());
        sq.displaySides();

        System.out.println(tr.getFigureType() + " | Area: " + tr.getArea());
        tr.displaySides();
    }
}
