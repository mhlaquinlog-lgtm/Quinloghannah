public class DemoSubscriptions {
    public static void main(String[] args) {
        PhysicalNewspaperSubscription p1 = new PhysicalNewspaperSubscription();
        p1.setName("Alice");
        p1.setAddress("123 Main St");
        System.out.println(p1.getName() + " | " + p1.getAddress() + " | $" + p1.getRate());

        PhysicalNewspaperSubscription p2 = new PhysicalNewspaperSubscription();
        p2.setName("Bob");
        p2.setAddress("No Number Lane");   // invalid

        OnlineNewspaperSubscription o1 = new OnlineNewspaperSubscription();
        o1.setName("Carol");
        o1.setAddress("carol@email.com");
        System.out.println(o1.getName() + " | " + o1.getAddress() + " | $" + o1.getRate());

        OnlineNewspaperSubscription o2 = new OnlineNewspaperSubscription();
        o2.setName("Dave");
        o2.setAddress("notanemail.com");   // invalid
    }
}
