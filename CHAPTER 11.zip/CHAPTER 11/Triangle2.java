public class Triangle2 extends GeometricFigure implements SidedObject {
    public Triangle2(double base, double height) {
        this.width = base;
        this.height = height;
        this.figureType = "Triangle";
        calculateArea();
    }

    @Override
    public void calculateArea() { area = 0.5 * width * height; }

    @Override
    public void displaySides() { System.out.println("A triangle has 3 sides."); }
}
