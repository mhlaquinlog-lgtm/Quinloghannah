package com.course.buildings;

public class School extends Building {
    private int classrooms;
    private String gradeLevel;

    public School(double squareFootage, int stories, int classrooms, String gradeLevel) {
        super(squareFootage, stories);
        this.classrooms = classrooms;
        this.gradeLevel = gradeLevel;
    }

    public int getClassrooms() { return classrooms; }
    public String getGradeLevel() { return gradeLevel; }
    public void setClassrooms(int c) { this.classrooms = c; }
    public void setGradeLevel(String g) { this.gradeLevel = g; }
}
