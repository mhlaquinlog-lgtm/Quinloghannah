public class UseDivision {
    public static void main(String[] args) {
        Division d1 = new InternationalDivision("TechGlobal", 1001, "Japan", "Japanese");
        Division d2 = new DomesticDivision("TechGlobal", 1002, "Illinois");
        Division d3 = new InternationalDivision("BuildCo", 2001, "Germany", "German");
        Division d4 = new DomesticDivision("BuildCo", 2002, "Texas");
        d1.display(); d2.display(); d3.display(); d4.display();
    }
}
