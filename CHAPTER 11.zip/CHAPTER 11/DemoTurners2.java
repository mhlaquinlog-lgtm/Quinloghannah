public class DemoTurners2 {
    public static void main(String[] args) {
        Turner leaf    = new Leaf();
        Turner page    = new Page();
        Turner pancake = new Pancake();
        Turner wheel   = new Wheel();
        Turner key     = new Key();
        leaf.turn();
        page.turn();
        pancake.turn();
        wheel.turn();
        key.turn();
    }
}
