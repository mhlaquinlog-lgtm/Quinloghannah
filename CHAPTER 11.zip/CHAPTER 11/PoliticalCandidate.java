public class PoliticalCandidate implements Runner {
    @Override
    public void run() { System.out.println("A candidate runs for office in an election."); }
}
