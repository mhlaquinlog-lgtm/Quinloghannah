import java.util.Scanner;

public class PurchaseArray {
    public static void main(String[] args) {
        Purchase[] purchases = new Purchase[5];
        Scanner input = new Scanner(System.in);

        for (int i = 0; i < purchases.length; i++) {
            purchases[i] = new Purchase();
            System.out.println("\nEnter data for Purchase #" + (i + 1));

            int inv;
            do {
                System.out.print("  Invoice number (1000-8000) >> ");
                inv = input.nextInt();
                if (inv < 1000 || inv > 8000)
                    System.out.println("  Error: Invoice must be between 1000 and 8000.");
            } while (inv < 1000 || inv > 8000);
            purchases[i].setInvoiceNumber(inv);

            double amount;
            do {
                System.out.print("  Sale amount (non-negative) >> ");
                amount = input.nextDouble();
                if (amount < 0)
                    System.out.println("  Error: Amount cannot be negative.");
            } while (amount < 0);
            purchases[i].setSaleAmount(amount);
        }

        System.out.println("\n=== Purchase Records ===");
        System.out.printf("%-10s %-12s %-12s %-12s%n",
            "Invoice", "Sale", "Tax(5%)", "Total");
        System.out.println("------------------------------------------");
        for (Purchase p : purchases)
            System.out.printf("%-10d $%-11.2f $%-11.2f $%-11.2f%n",
                p.getInvoiceNumber(), p.getSaleAmount(),
                p.getSalesTax(), p.getTotal());
    }
}