public class CertOfDeposit {
    private int accountNumber;
    private String ownerLastName;
    private double depositAmount;
    private int term;   // in months

    public CertOfDeposit(int acct, String lastName, double amount, int term) {
        this.accountNumber  = acct;
        this.ownerLastName  = lastName;
        this.depositAmount  = amount;
        this.term           = term;
    }

    public int    getAccountNumber()  { return accountNumber; }
    public String getOwnerLastName()  { return ownerLastName; }
    public double getDepositAmount()  { return depositAmount; }
    public int    getTerm()           { return term; }
}