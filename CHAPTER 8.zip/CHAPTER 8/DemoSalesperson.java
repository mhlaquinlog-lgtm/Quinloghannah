public class DemoSalesperson {
    public static void main(String[] args) {
        Salesperson[] staff = new Salesperson[10];

        for (int i = 0; i < staff.length; i++)
            staff[i] = new Salesperson(9999, 0.0);

        System.out.printf("%-10s %-15s%n", "ID", "Annual Sales");
        System.out.println("-------------------------");
        for (Salesperson s : staff)
            System.out.printf("%-10d $%-14.2f%n", s.getId(), s.getAnnualSales());
    }
}