import java.util.Scanner;

public class CategorizeStrings2 {
    public static void main(String[] args) {
        String[] noSpace   = new String[10];
        String[] oneSpace  = new String[10];
        String[] moreSpace = new String[10];
        int noCount = 0, oneCount = 0, moreCount = 0, total = 0;
        Scanner input = new Scanner(System.in);

        System.out.println("Enter up to 10 strings. Type QUIT to stop.");

        while (total < 10) {
            System.out.print("Enter string " + (total + 1) + " >> ");
            String s = input.nextLine();
            if (s.equalsIgnoreCase("QUIT"))
                break;

            int spaces = 0;
            for (char c : s.toCharArray())
                if (c == ' ') spaces++;

            if (spaces == 0)       noSpace[noCount++] = s;
            else if (spaces == 1)  oneSpace[oneCount++] = s;
            else                   moreSpace[moreCount++] = s;
            total++;
        }

        String choice;
        do {
            System.out.print("\nDisplay strings with '0', '1', or 'more' spaces? (QUIT to exit) >> ");
            choice = input.nextLine();

            if (choice.equals("0")) {
                System.out.println("Strings with no spaces:");
                if (noCount == 0) System.out.println("  (none)");
                else for (int i = 0; i < noCount; i++) System.out.println("  " + noSpace[i]);
            } else if (choice.equals("1")) {
                System.out.println("Strings with one space:");
                if (oneCount == 0) System.out.println("  (none)");
                else for (int i = 0; i < oneCount; i++) System.out.println("  " + oneSpace[i]);
            } else if (choice.equalsIgnoreCase("more")) {
                System.out.println("Strings with more than one space:");
                if (moreCount == 0) System.out.println("  (none)");
                else for (int i = 0; i < moreCount; i++) System.out.println("  " + moreSpace[i]);
            } else if (!choice.equalsIgnoreCase("QUIT")) {
                System.out.println("All entered strings:");
                for (int i = 0; i < noCount; i++)   System.out.println("  " + noSpace[i]);
                for (int i = 0; i < oneCount; i++)  System.out.println("  " + oneSpace[i]);
                for (int i = 0; i < moreCount; i++) System.out.println("  " + moreSpace[i]);
            }
        } while (!choice.equalsIgnoreCase("QUIT"));

        System.out.println("Goodbye!");
    }
}