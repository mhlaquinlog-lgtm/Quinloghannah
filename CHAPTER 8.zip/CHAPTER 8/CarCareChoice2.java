import java.util.Scanner;

public class CarCareChoice2 {
    public static void main(String[] args) {
        String[] services = {"oil change", "tire rotation", "battery check", "brake inspection"};
        int[]    prices   = {25, 22, 15, 5};
        Scanner input = new Scanner(System.in);

        System.out.println("=== Cody's Car Care Shop ===");
        System.out.println("Available services:");
        for (int i = 0; i < services.length; i++)
            System.out.println("  - " + services[i] + " ($" + prices[i] + ")");

        System.out.print("\nEnter first 3 characters of a service >> ");
        String choice = input.nextLine().toLowerCase();

        // Need at least 3 characters to compare
        if (choice.length() < 3) {
            System.out.println("Error: Please enter at least 3 characters.");
            return;
        }

        String prefix = choice.substring(0, 3);
        boolean found = false;

        for (int i = 0; i < services.length; i++) {
            if (services[i].substring(0, 3).equals(prefix)) {
                System.out.println("Service: " + services[i] + "  Price: $" + prices[i]);
                found = true;
                break;
            }
        }
        if (!found)
            System.out.println("Error: \"" + choice + "\" does not match any service.");
    }
}