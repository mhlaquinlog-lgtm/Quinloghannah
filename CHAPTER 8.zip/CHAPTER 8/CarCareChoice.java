import java.util.Scanner;

public class CarCareChoice {
    public static void main(String[] args) {
        String[] services = {"oil change", "tire rotation", "battery check", "brake inspection"};
        int[]    prices   = {25, 22, 15, 5};
        Scanner input = new Scanner(System.in);

        System.out.println("=== Cody's Car Care Shop ===");
        System.out.println("Available services:");
        for (int i = 0; i < services.length; i++)
            System.out.println("  - " + services[i] + " ($" + prices[i] + ")");

        System.out.print("\nEnter a service >> ");
        String choice = input.nextLine().toLowerCase();

        boolean found = false;
        for (int i = 0; i < services.length; i++) {
            if (choice.equals(services[i])) {
                System.out.println("Service: " + services[i] + "  Price: $" + prices[i]);
                found = true;
                break;
            }
        }
        if (!found)
            System.out.println("Error: \"" + choice + "\" is not a valid service.");
    }
}