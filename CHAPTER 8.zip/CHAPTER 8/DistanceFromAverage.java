import java.util.Scanner;

public class DistanceFromAverage {
    public static void main(String[] args) {
        double[] values = new double[20];
        int count = 0;
        double sum = 0;
        Scanner input = new Scanner(System.in);

        System.out.println("Enter up to 20 doubles. Enter 99999 to quit.");

        while (count < 20) {
            System.out.print("Enter value " + (count + 1) + " >> ");
            double val = input.nextDouble();
            if (val == 99999)
                break;
            values[count] = val;
            sum += val;
            count++;
        }

        if (count == 0) {
            System.out.println("Error: No numbers were entered.");
        } else {
            double average = sum / count;
            System.out.printf("%nAverage: %.2f%n%n", average);
            System.out.printf("%-10s %-20s%n", "Value", "Distance from Average");
            System.out.println("-------------------------------");
            for (int i = 0; i < count; i++) {
                double distance = Math.abs(values[i] - average);
                System.out.printf("%-10.2f %-20.2f%n", values[i], distance);
            }
        }
    }
}