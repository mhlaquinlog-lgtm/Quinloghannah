public class TwelveInts {
    public static void main(String[] args) {
        int[] nums = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120};

        System.out.println("First to last:");
        for (int i = 0; i < nums.length; i++)
            System.out.print(nums[i] + "  ");

        System.out.println("\n\nLast to first:");
        for (int i = nums.length - 1; i >= 0; i--)
            System.out.print(nums[i] + "  ");

        System.out.println();
    }
}