import java.util.Scanner;

public class CategorizeStrings {
    public static void main(String[] args) {
        String[] shortStrings = new String[10];
        String[] longStrings  = new String[10];
        int shortCount = 0, longCount = 0, total = 0;
        Scanner input = new Scanner(System.in);

        System.out.println("Enter up to 10 strings. Type QUIT to stop.");

        while (total < 10) {
            System.out.print("Enter string " + (total + 1) + " >> ");
            String s = input.nextLine();
            if (s.equalsIgnoreCase("QUIT"))
                break;
            if (s.length() <= 10)
                shortStrings[shortCount++] = s;
            else
                longStrings[longCount++] = s;
            total++;
        }

        String choice;
        do {
            System.out.print("\nDisplay 'short' or 'long' strings? (QUIT to exit) >> ");
            choice = input.nextLine();

            if (choice.equalsIgnoreCase("short")) {
                if (shortCount == 0)
                    System.out.println("No short strings were entered.");
                else {
                    System.out.println("Short strings (10 chars or fewer):");
                    for (int i = 0; i < shortCount; i++)
                        System.out.println("  " + shortStrings[i]);
                }
            } else if (!choice.equalsIgnoreCase("QUIT")) {
                if (longCount == 0)
                    System.out.println("No long strings were entered.");
                else {
                    System.out.println("Long strings (more than 10 chars):");
                    for (int i = 0; i < longCount; i++)
                        System.out.println("  " + longStrings[i]);
                }
            }
        } while (!choice.equalsIgnoreCase("QUIT"));

        System.out.println("Goodbye!");
    }
}