public class DemoSalesperson2 {
    public static void main(String[] args) {
        Salesperson[] staff = new Salesperson[10];
        int startId = 111;
        double startSales = 25000.0;

        for (int i = 0; i < staff.length; i++)
            staff[i] = new Salesperson(startId + i, startSales + (i * 5000));

        System.out.printf("%-10s %-15s%n", "ID", "Annual Sales");
        System.out.println("-------------------------");
        for (Salesperson s : staff)
            System.out.printf("%-10d $%-14.2f%n", s.getId(), s.getAnnualSales());
    }
}