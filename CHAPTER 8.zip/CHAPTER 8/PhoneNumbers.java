import java.util.Scanner;

public class PhoneNumbers {
    public static void main(String[] args) {
        String[] names   = new String[30];
        String[] numbers = new String[30];
        int count = 10;

        // Pre-fill first 10
        names[0] = "Alice";   numbers[0] = "555-1001";
        names[1] = "Bob";     numbers[1] = "555-1002";
        names[2] = "Carol";   numbers[2] = "555-1003";
        names[3] = "David";   numbers[3] = "555-1004";
        names[4] = "Eve";     numbers[4] = "555-1005";
        names[5] = "Frank";   numbers[5] = "555-1006";
        names[6] = "Grace";   numbers[6] = "555-1007";
        names[7] = "Hank";    numbers[7] = "555-1008";
        names[8] = "Irene";   numbers[8] = "555-1009";
        names[9] = "Jack";    numbers[9] = "555-1010";

        Scanner input = new Scanner(System.in);
        String search;

        while (true) {
            System.out.print("\nEnter a name to search (or 'quit') >> ");
            search = input.nextLine();
            if (search.equalsIgnoreCase("quit"))
                break;

            boolean found = false;
            for (int i = 0; i < count; i++) {
                if (names[i].equalsIgnoreCase(search)) {
                    System.out.println("Phone number for " + names[i] + ": " + numbers[i]);
                    found = true;
                    break;
                }
            }

            if (!found) {
                if (count >= 30) {
                    System.out.println("Directory is full. Cannot add new entries.");
                } else {
                    System.out.print("\"" + search + "\" not found. Enter phone number >> ");
                    String newNum = input.nextLine();
                    names[count]   = search;
                    numbers[count] = newNum;
                    count++;
                    System.out.println("Added: " + search + " - " + newNum);
                }
            }
        }
        System.out.println("Goodbye!");
    }
}