import java.util.Scanner;

public class CertOfDepositArray {
    public static void main(String[] args) {
        CertOfDeposit[] certs = new CertOfDeposit[5];
        Scanner input = new Scanner(System.in);

        for (int i = 0; i < certs.length; i++) {
            System.out.println("\nEnter data for CD #" + (i + 1));
            System.out.print("  Account number >> ");
            int acct = input.nextInt();
            input.nextLine();
            System.out.print("  Owner last name >> ");
            String lastName = input.nextLine();
            System.out.print("  Deposit amount >> ");
            double amount = input.nextDouble();
            System.out.print("  Term (months)  >> ");
            int term = input.nextInt();
            input.nextLine();
            certs[i] = new CertOfDeposit(acct, lastName, amount, term);
        }

        System.out.println("\n=== Certificate of Deposit Records ===");
        System.out.printf("%-10s %-15s %-15s %-10s%n",
            "Acct #", "Last Name", "Deposit", "Term");
        System.out.println("--------------------------------------------------");
        for (CertOfDeposit cd : certs)
            System.out.printf("%-10d %-15s $%-14.2f %-10d months%n",
                cd.getAccountNumber(), cd.getOwnerLastName(),
                cd.getDepositAmount(), cd.getTerm());
    }
}