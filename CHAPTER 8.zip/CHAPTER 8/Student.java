public class Student {
    private int studentId;
    private CollegeCourse[] courses = new CollegeCourse[5];

    public int getStudentId() { return studentId; }
    public void setStudentId(int id) { this.studentId = id; }

    public CollegeCourse getCourse(int position) {
        return courses[position];
    }

    public void setCourse(CollegeCourse course, int position) {
        courses[position] = course;
    }
}