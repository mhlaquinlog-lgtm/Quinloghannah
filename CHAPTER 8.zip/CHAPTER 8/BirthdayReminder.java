import java.util.Scanner;

public class BirthdayReminder {
    public static void main(String[] args) {
        String[] names     = new String[10];
        String[] birthdays = new String[10];
        int count = 0;
        Scanner input = new Scanner(System.in);

        System.out.println("Enter up to 10 friends (ZZZ to stop).");

        while (count < 10) {
            System.out.print("Enter name >> ");
            String name = input.nextLine();
            if (name.equalsIgnoreCase("ZZZ"))
                break;
            System.out.print("Enter birthdate (e.g. Jan 1) >> ");
            String bday = input.nextLine();
            names[count]     = name;
            birthdays[count] = bday;
            count++;
        }

        System.out.println("\nTotal names entered: " + count);
        System.out.println("Names entered:");
        for (int i = 0; i < count; i++)
            System.out.println("  " + names[i]);

        String search;
        do {
            System.out.print("\nEnter a name to look up (ZZZ to quit) >> ");
            search = input.nextLine();
            if (search.equalsIgnoreCase("ZZZ"))
                break;

            boolean found = false;
            for (int i = 0; i < count; i++) {
                if (names[i].equalsIgnoreCase(search)) {
                    System.out.println(names[i] + "'s birthday is: " + birthdays[i]);
                    found = true;
                    break;
                }
            }
            if (!found)
                System.out.println("Error: \"" + search + "\" was not found.");
        } while (true);

        System.out.println("Goodbye!");
    }
}