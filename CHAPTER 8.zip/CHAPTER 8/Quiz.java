import java.util.Scanner;

public class Quiz {
    public static void main(String[] args) {
        String[] questions = {
            "What is the capital of France?",
            "Which planet is closest to the Sun?",
            "What is 7 x 8?",
            "Who wrote Romeo and Juliet?",
            "What is the chemical symbol for water?",
            "How many sides does a hexagon have?",
            "What is the largest ocean?",
            "Which gas do plants absorb?",
            "How many continents are there?",
            "What color is the sky on a clear day?"
        };

        String[][] choices = {
            {"A. Berlin",  "B. Paris",   "C. Madrid"},
            {"A. Mercury", "B. Venus",   "C. Earth"},
            {"A. 54",      "B. 56",      "C. 58"},
            {"A. Dickens", "B. Tolkien", "C. Shakespeare"},
            {"A. CO2",     "B. H2O",     "C. O2"},
            {"A. 5",       "B. 6",       "C. 7"},
            {"A. Atlantic","B. Indian",  "C. Pacific"},
            {"A. Oxygen",  "B. CO2",     "C. Nitrogen"},
            {"A. 5",       "B. 6",       "C. 7"},
            {"A. Green",   "B. Blue",    "C. Yellow"}
        };

        char[] answers = {'B','A','B','C','B','B','C','B','C','B'};
        Scanner input = new Scanner(System.in);
        int correct = 0, incorrect = 0;

        System.out.println("=== TRIVIA QUIZ ===\n");

        for (int i = 0; i < questions.length; i++) {
            System.out.println("Q" + (i+1) + ": " + questions[i]);
            for (String c : choices[i]) System.out.println("  " + c);

            char answer;
            do {
                System.out.print("Your answer (A/B/C) >> ");
                answer = input.nextLine().toUpperCase().charAt(0);
                if (answer != 'A' && answer != 'B' && answer != 'C')
                    System.out.println("Invalid! Please enter A, B, or C.");
            } while (answer != 'A' && answer != 'B' && answer != 'C');

            if (answer == answers[i]) {
                System.out.println("Correct!\n");
                correct++;
            } else {
                System.out.println("The correct answer is " + answers[i] + "\n");
                incorrect++;
            }
        }

        System.out.println("=== RESULTS ===");
        System.out.println("Correct:   " + correct);
        System.out.println("Incorrect: " + incorrect);
    }
}