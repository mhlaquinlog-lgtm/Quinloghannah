import java.util.Scanner;

public class InputGrades {
    public static void main(String[] args) {
        Student[] students = new Student[10];
        Scanner input = new Scanner(System.in);

        for (int s = 0; s < students.length; s++) {
            students[s] = new Student();
            System.out.print("Enter ID for student #" + (s + 1) + " >> ");
            students[s].setStudentId(input.nextInt());
            input.nextLine(); // consume newline

            for (int c = 0; c < 5; c++) {
                CollegeCourse course = new CollegeCourse();

                System.out.print("  Enter course ID #" + (c + 1) + " >> ");
                course.setCourseId(input.nextLine());

                System.out.print("  Enter credit hours for course #" + (c + 1) + " >> ");
                course.setCreditHours(input.nextInt());
                input.nextLine();

                char grade;
                do {
                    System.out.print("  Enter grade (A/B/C/D/F) for course #" + (c + 1) + " >> ");
                    grade = input.nextLine().toUpperCase().charAt(0);
                    if (grade != 'A' && grade != 'B' && grade != 'C'
                            && grade != 'D' && grade != 'F')
                        System.out.println("  Invalid grade. Enter A, B, C, D, or F only.");
                } while (grade != 'A' && grade != 'B' && grade != 'C'
                        && grade != 'D' && grade != 'F');

                course.setGrade(grade);
                students[s].setCourse(course, c);
            }
        }

        System.out.println("\n=== Student Grade Report ===");
        for (int s = 0; s < students.length; s++) {
            System.out.println("\nStudent ID: " + students[s].getStudentId());
            System.out.printf("  %-12s %-8s %-6s%n", "Course ID", "Credits", "Grade");
            System.out.println("  ----------------------------");
            for (int c = 0; c < 5; c++) {
                CollegeCourse cc = students[s].getCourse(c);
                System.out.printf("  %-12s %-8d %-6c%n",
                    cc.getCourseId(), cc.getCreditHours(), cc.getGrade());
            }
        }
    }
}