public class Purchase {
    private int invoiceNumber;
    private double saleAmount;
    private double salesTax;
    private static final double TAX_RATE = 0.05;

    public void setInvoiceNumber(int inv) { this.invoiceNumber = inv; }
    public int  getInvoiceNumber()        { return invoiceNumber; }

    public void setSaleAmount(double amount) {
        this.saleAmount = amount;
        this.salesTax   = amount * TAX_RATE;
    }
    public double getSaleAmount() { return saleAmount; }
    public double getSalesTax()   { return salesTax; }
    public double getTotal()      { return saleAmount + salesTax; }
}