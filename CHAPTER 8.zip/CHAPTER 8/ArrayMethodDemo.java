public class ArrayMethodDemo {
    public static void main(String[] args) {
        int[] nums = {45, 12, 78, 34, 56, 90, 23, 67, 8, 100};
        int limit = 50;

        System.out.println("=== Array Method Demo ===\n");

        System.out.print("(1) All integers: ");
        displayAll(nums);

        System.out.print("(2) Reversed:     ");
        displayReversed(nums);

        displaySum(nums);

        displayLessThan(nums, limit);

        displayAboveAverage(nums);
    }

    public static void displayAll(int[] arr) {
        for (int n : arr)
            System.out.print(n + "  ");
        System.out.println();
    }

    public static void displayReversed(int[] arr) {
        for (int i = arr.length - 1; i >= 0; i--)
            System.out.print(arr[i] + "  ");
        System.out.println();
    }

    public static void displaySum(int[] arr) {
        int sum = 0;
        for (int n : arr)
            sum += n;
        System.out.println("(3) Sum:          " + sum);
    }

    public static void displayLessThan(int[] arr, int limit) {
        System.out.print("(4) Values < " + limit + ": ");
        for (int n : arr)
            if (n < limit)
                System.out.print(n + "  ");
        System.out.println();
    }

    public static void displayAboveAverage(int[] arr) {
        double sum = 0;
        for (int n : arr) sum += n;
        double avg = sum / arr.length;
        System.out.printf("(5) Above avg (%.1f): ", avg);
        for (int n : arr)
            if (n > avg)
                System.out.print(n + "  ");
        System.out.println();
    }
}