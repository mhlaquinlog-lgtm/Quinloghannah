public class DemoOverload
{
    public static void main(String[] args)
    {

        displayDate(5);
        displayDate(5, 12);
        displayDate(5, 12, 2025);
    }

    public static void displayDate(int mm)
    {
        System.out.println("Event date " + mm + "/1/2016");
    }

    public static void displayDate(int mm, int dd)
    {
        System.out.println("Event date " + mm + "/" + dd + "/2016");
    }

    public static void displayDate(int mm, int dd, int yy)
    {
        System.out.println("Event date " + mm + "/" + dd + "/" + yy);
    }
}