public class ShortCircuitTestOr
{
    public static void main(String[] args)
    {
        if(falseMethod() || trueMethod())
            System.out.println("At least one is true");
        else
            System.out.println("None are true");

        System.out.println();

        if(trueMethod() || falseMethod())
            System.out.println("At least one is true");
        else
            System.out.println("None are true");
    }

    public static boolean trueMethod()
    {
        System.out.println("True method");
        return true;
    }

    public static boolean falseMethod()
    {
        System.out.println("False method");
        return false;
    }
}