public class TestDogs2
{
    public static void main(String[] args)
    {
        // Valid data
        DogTriathlonParticipant2 dog1 =
            new DogTriathlonParticipant2("Rex", 3, 10, 9, 8);

        // Invalid (events don't match scores)
        DogTriathlonParticipant2 dog2 =
            new DogTriathlonParticipant2("Buddy", 2, 10, 0, 7);

        // Invalid example
        DogTriathlonParticipant2 dog3 =
            new DogTriathlonParticipant2("Max", 1, 5, 6, 7);

        dog1.display();
        dog2.display();
        dog3.display();
    }
}