public class DogTriathlonParticipant3
{
    private String name;
    private int numEvents;
    private int obedienceScore;
    private int conformationScore;
    private int agilityScore;
    private double avg;
    private boolean scoresAgree;

    public DogTriathlonParticipant3(String dogName,
                                    int numEvents,
                                    int s1,
                                    int s2,
                                    int s3)
    {
        name = dogName;
        this.numEvents = numEvents;

        if(numEvents == 0 && s1==0 && s2==0 && s3==0)
            scoresAgree = true;
        else if(numEvents == 1 &&
               ((s1!=0 && s2==0 && s3==0) ||
                (s1==0 && s2!=0 && s3==0) ||
                (s1==0 && s2==0 && s3!=0)))
            scoresAgree = true;
        else if(numEvents == 2 &&
               ((s1!=0 && s2!=0 && s3==0) ||
                (s1!=0 && s2==0 && s3!=0) ||
                (s1==0 && s2!=0 && s3!=0)))
            scoresAgree = true;
        else if(numEvents == 3 &&
                s1!=0 && s2!=0 && s3!=0)
            scoresAgree = true;
        else
            scoresAgree = false;

        if(scoresAgree)
        {
            obedienceScore = s1;
            conformationScore = s2;
            agilityScore = s3;
        }

        int total = obedienceScore +
                    conformationScore +
                    agilityScore;

        if(numEvents == 0)
            avg = 0;
        else
            avg = (double) total / numEvents;
    }

    public void display()
    {
        System.out.println("\nDog: " + name);
        System.out.println("Average Score: " + avg);

        if(!scoresAgree)
            System.out.println("Notice! Invalid event/score combination.");
    }
}