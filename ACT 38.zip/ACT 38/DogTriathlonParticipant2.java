public class DogTriathlonParticipant2
{
    private String name;
    private int numEvents;
    private int obedienceScore;
    private int conformationScore;
    private int agilityScore;
    private double avg;
    private boolean scoresAgree;

    private final int NUM_EVENTS;

    public DogTriathlonParticipant2(String dogName,
                                    int numEvents,
                                    int score1,
                                    int score2,
                                    int score3)
    {
        name = dogName;
        this.numEvents = numEvents;
        NUM_EVENTS = numEvents;

        int totalNot0 = 0;

        if(score1 != 0)
            totalNot0 = totalNot0 + 1;
        if(score2 != 0)
            totalNot0 = totalNot0 + 1;
        if(score3 != 0)
            totalNot0 = totalNot0 + 1;

        if(numEvents == totalNot0)
            scoresAgree = true;
        else
            scoresAgree = false;

        if(scoresAgree)
        {
            obedienceScore = score1;
            conformationScore = score2;
            agilityScore = score3;
        }
        else
        {
            obedienceScore = 0;
            conformationScore = 0;
            agilityScore = 0;
        }

        int total = obedienceScore +
                    conformationScore +
                    agilityScore;

        if(NUM_EVENTS == 0)
            avg = 0;
        else
            avg = (double) total / NUM_EVENTS;
    }

    public void display()
    {
        System.out.println("\nDog Name: " + name);
        System.out.println("Events: " + numEvents);
        System.out.println("Obedience Score: " + obedienceScore);
        System.out.println("Conformation Score: " + conformationScore);
        System.out.println("Agility Score: " + agilityScore);
        System.out.println("Average Score: " + avg);

        if(!scoresAgree)
            System.out.println(
            "Notice! Number of events for " + name +
            " does not agree with scores reported.");
    }
}