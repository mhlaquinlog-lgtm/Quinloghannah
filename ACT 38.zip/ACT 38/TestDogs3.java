public class TestDogs3
{
    public static void main(String[] args)
    {
        DogTriathlonParticipant3 d1 =
            new DogTriathlonParticipant3("Ace",3,8,9,10);

        DogTriathlonParticipant3 d2 =
            new DogTriathlonParticipant3("Bolt",2,7,0,6);

        DogTriathlonParticipant3 d3 =
            new DogTriathlonParticipant3("Charlie",1,0,5,0);

        DogTriathlonParticipant3 d4 =
            new DogTriathlonParticipant3("ErrorDog",2,5,6,7);

        d1.display();
        d2.display();
        d3.display();
        d4.display();
    }
}