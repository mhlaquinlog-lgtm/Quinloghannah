public class TestCircle {
    public static void main(String[] args) {

        Circle c1 = new Circle();
        Circle c2 = new Circle();
        Circle c3 = new Circle();

        c1.setRadius(2);
        c2.setRadius(10);

        display(c1);
        display(c2);
        display(c3);
    }

    static void display(Circle c){
        System.out.println(c.getRadius()+" "
                +c.getDiameter()+" "
                +c.getArea());
    }
}