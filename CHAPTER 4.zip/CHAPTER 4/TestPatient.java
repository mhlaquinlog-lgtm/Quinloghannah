public class TestPatient {
    public static void main(String[] args) {

        BloodData b = new BloodData("B","+");
        Patient p = new Patient("101",20,b);

        System.out.println(p.getId());
        System.out.println(p.getAge());
        System.out.println(p.getBlood().getBloodType());
    }
}