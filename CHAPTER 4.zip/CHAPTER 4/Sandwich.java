public class Sandwich {

    private Bread bread;
    private SandwichFilling filling;

    public Sandwich(String type,int breadCal,
                    String fill,int fillCal){

        bread = new Bread(type,breadCal);
        filling = new SandwichFilling(fill,fillCal);
    }

    public int totalCalories(){
        return (bread.getCalories()*2)
                + filling.getCalories();
    }

    public void display(){
        System.out.println(bread.getType()+" sandwich with "
                + filling.getFilling());
        System.out.println("Total Calories: "
                + totalCalories());
    }
}