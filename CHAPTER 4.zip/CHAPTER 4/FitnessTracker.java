import java.time.LocalDate;

public class FitnessTracker {

    private String activity;
    private int minutes;
    private LocalDate date;

    public FitnessTracker() {
        activity = "running";
        minutes = 0;
        date = LocalDate.of(LocalDate.now().getYear(), 1, 1);
    }

    public String getActivity() { return activity; }
    public int getMinutes() { return minutes; }
    public LocalDate getDate() { return date; }
}