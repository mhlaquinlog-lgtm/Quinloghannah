public class BloodData {

    private String bloodType;
    private String rhFactor;

    public BloodData() {
        bloodType = "O";
        rhFactor = "+";
    }

    public BloodData(String type, String rh) {
        bloodType = type;
        rhFactor = rh;
    }

    public void setBloodType(String type){ bloodType = type; }
    public void setRhFactor(String rh){ rhFactor = rh; }

    public String getBloodType(){ return bloodType; }
    public String getRhFactor(){ return rhFactor; }
}