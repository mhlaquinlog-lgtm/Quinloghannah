public class FiveDice {

    public static void main(String[] args) {

        System.out.println("Computer:");
        for(int i=0;i<5;i++)
            System.out.print(new Die().getValue()+" ");

        System.out.println("\nPlayer:");
        for(int i=0;i<5;i++)
            System.out.print(new Die().getValue()+" ");
    }
}