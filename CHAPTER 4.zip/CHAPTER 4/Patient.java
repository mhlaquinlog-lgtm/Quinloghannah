public class Patient {

    private String id;
    private int age;
    private BloodData blood;

    public Patient() {
        id = "0";
        age = 0;
        blood = new BloodData();
    }

    public Patient(String id, int age, BloodData blood) {
        this.id = id;
        this.age = age;
        this.blood = blood;
    }

    public String getId(){ return id; }
    public int getAge(){ return age; }
    public BloodData getBlood(){ return blood; }
}