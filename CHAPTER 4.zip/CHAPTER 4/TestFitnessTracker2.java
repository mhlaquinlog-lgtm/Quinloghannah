import java.time.LocalDate;

public class TestFitnessTracker2 {
    public static void main(String[] args) {

        FitnessTracker2 f1 = new FitnessTracker2();
        FitnessTracker2 f2 =
            new FitnessTracker2("Swimming",30,
            LocalDate.of(2026,2,20));

        System.out.println(f1.getActivity());
        System.out.println(f2.getActivity());
    }
}