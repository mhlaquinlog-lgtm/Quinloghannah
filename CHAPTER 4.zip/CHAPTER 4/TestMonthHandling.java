import java.time.LocalDate;

public class TestMonthHandling {

    public static void main(String[] args) {

        int year = LocalDate.now().getYear();

        LocalDate jan31 = LocalDate.of(year,1,31);
        LocalDate dec31 = LocalDate.of(year,12,31);

        for(int i=1;i<=3;i++){
            System.out.println(jan31.plusMonths(i));
            System.out.println(dec31.plusMonths(i));
        }
    }
}