public class TwoDice {

    public static void main(String[] args) {

        Die d1 = new Die();
        Die d2 = new Die();

        System.out.println(d1.getValue());
        System.out.println(d2.getValue());
    }
}