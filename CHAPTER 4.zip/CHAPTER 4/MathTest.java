public class MathTest {

    public static void main(String[] args) {

        System.out.println(Math.sqrt(37));

        System.out.println(Math.sin(Math.toRadians(300)));
        System.out.println(Math.cos(Math.toRadians(300)));

        System.out.println(Math.floor(22.8));
        System.out.println(Math.ceil(22.8));
        System.out.println(Math.round(22.8));

        System.out.println(Math.max('D',71));
        System.out.println(Math.min('D',71));

        int random = (int)(Math.random()*21);
        System.out.println(random);
    }
}