public class TestBread {
    public static void main(String[] args) {

        Bread b1 = new Bread("Rye",80);
        Bread b2 = new Bread("Wheat",90);
        Bread b3 = new Bread("White",100);

        System.out.println(Bread.MOTTO);

        System.out.println(b1.getType()+" "+b1.getCalories());
        System.out.println(b2.getType()+" "+b2.getCalories());
        System.out.println(b3.getType()+" "+b3.getCalories());
    }
}