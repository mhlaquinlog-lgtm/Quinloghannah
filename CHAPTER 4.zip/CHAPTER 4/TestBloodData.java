public class TestBloodData {
    public static void main(String[] args) {
        BloodData b = new BloodData("A","-");

        System.out.println(b.getBloodType());
        System.out.println(b.getRhFactor());
    }
}