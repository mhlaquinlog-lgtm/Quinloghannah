public class Bread {

    private String type;
    private int calories;
    public final static String MOTTO = "The staff of life";

    public Bread(String t, int c){
        type = t;
        calories = c;
    }

    public String getType(){ return type; }
    public int getCalories(){ return calories; }
}