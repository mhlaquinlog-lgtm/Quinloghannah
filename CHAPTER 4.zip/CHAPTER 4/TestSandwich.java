public class TestSandwich {
    public static void main(String[] args) {

        Sandwich s1 =
            new Sandwich("Wheat",90,"Ham",250);
        Sandwich s2 =
            new Sandwich("White",100,"Tuna",220);
        Sandwich s3 =
            new Sandwich("Rye",80,"Egg",200);

        s1.display();
        s2.display();
        s3.display();
    }
}