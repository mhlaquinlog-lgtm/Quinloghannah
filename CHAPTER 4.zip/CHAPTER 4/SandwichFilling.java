public class SandwichFilling {

    private String filling;
    private int calories;

    public SandwichFilling(String f,int c){
        filling = f;
        calories = c;
    }

    public String getFilling(){ return filling; }
    public int getCalories(){ return calories; }
}