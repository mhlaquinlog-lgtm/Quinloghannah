public class Die {

    public static final int LOWEST_DIE_VALUE = 1;
    public static final int HIGHEST_DIE_VALUE = 6;

    private int value;

    public Die(){
        value = ((int)(Math.random()*100)
                % HIGHEST_DIE_VALUE
                + LOWEST_DIE_VALUE);
    }

    public int getValue(){
        return value;
    }
}