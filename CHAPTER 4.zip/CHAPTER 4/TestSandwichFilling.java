public class TestSandwichFilling {
    public static void main(String[] args) {

        SandwichFilling s1 =
            new SandwichFilling("Egg Salad",200);
        SandwichFilling s2 =
            new SandwichFilling("Ham",250);
        SandwichFilling s3 =
            new SandwichFilling("Tuna",220);

        System.out.println(s1.getFilling());
        System.out.println(s2.getFilling());
        System.out.println(s3.getFilling());
    }
}