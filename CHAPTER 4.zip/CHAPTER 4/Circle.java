public class Circle {

    private double radius;
    private double diameter;
    private double area;

    public Circle(){
        setRadius(1);
    }

    public void setRadius(double r){
        radius = r;
        diameter = 2 * r;
        area = Math.PI * r * r;
    }

    public double getRadius(){ return radius; }
    public double getDiameter(){ return diameter; }
    public double getArea(){ return area; }
}