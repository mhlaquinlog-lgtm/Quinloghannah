public class Billing {

    public static double computeBill(double price) {
        return price * 1.08;
    }

    public static double computeBill(double price, int quantity) {
        return (price * quantity) * 1.08;
    }

    public static double computeBill(double price, int quantity, double coupon) {
        double total = (price * quantity) - coupon;
        return total * 1.08;
    }

    public static void main(String[] args) {
        System.out.println(computeBill(20));
        System.out.println(computeBill(20, 3));
        System.out.println(computeBill(20, 3, 10));
    }
}