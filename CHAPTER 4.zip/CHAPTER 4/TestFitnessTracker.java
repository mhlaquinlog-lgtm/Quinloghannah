public class TestFitnessTracker {
    public static void main(String[] args) {
        FitnessTracker ft = new FitnessTracker();

        System.out.println(ft.getActivity());
        System.out.println(ft.getMinutes());
        System.out.println(ft.getDate());
    }
}