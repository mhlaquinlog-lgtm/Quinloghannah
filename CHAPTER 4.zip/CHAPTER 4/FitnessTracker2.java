import java.time.LocalDate;

public class FitnessTracker2 {

    private String activity;
    private int minutes;
    private LocalDate date;

    public FitnessTracker2() {
        this("running", 0,
            LocalDate.of(LocalDate.now().getYear(),1,1));
    }

    public FitnessTracker2(String a, int m, LocalDate d) {
        activity = a;
        minutes = m;
        date = d;
    }

    public String getActivity(){ return activity; }
    public int getMinutes(){ return minutes; }
    public LocalDate getDate(){ return date; }
}