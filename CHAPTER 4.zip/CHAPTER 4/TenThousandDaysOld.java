import java.time.LocalDate;

public class TenThousandDaysOld {

    public static void main(String[] args) {

        LocalDate birth = LocalDate.of(2005,1,1); // change
        LocalDate result = birth.plusDays(10000);

        System.out.println("10,000 days old on: " + result);
    }
}