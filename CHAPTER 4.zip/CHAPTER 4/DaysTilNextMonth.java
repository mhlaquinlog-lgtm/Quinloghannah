import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class DaysTilNextMonth {

    public static void main(String[] args) {

        LocalDate today = LocalDate.now();
        LocalDate nextMonth =
            today.plusMonths(1).withDayOfMonth(1);

        long days =
            ChronoUnit.DAYS.between(today,nextMonth);

        System.out.println("Days until "
            + nextMonth.getMonth() + ": " + days);
    }
}