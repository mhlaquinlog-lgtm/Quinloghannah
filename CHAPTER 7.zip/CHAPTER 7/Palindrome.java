import java.util.Scanner;

public class Palindrome {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter phrase: ");
        String phrase = input.nextLine().toLowerCase().replaceAll("[^a-z]", "");

        String reversed = new StringBuilder(phrase).reverse().toString();

        if(phrase.equals(reversed))
            System.out.println("Palindrome");
        else
            System.out.println("Not a palindrome");
    }
}