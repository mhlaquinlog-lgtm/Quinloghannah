public class TaxReturn {

    private String ssn, lastName, firstName, address, city, state, zip, status;
    private double income, tax;

    public TaxReturn(String ssn, String lastName, String firstName,
                     String address, String city, String state,
                     String zip, double income, String status) {

        this.ssn = ssn;
        this.lastName = lastName;
        this.firstName = firstName;
        this.address = address;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.income = income;
        this.status = status;

        calculateTax();
    }

    private void calculateTax() {
        if(status.equalsIgnoreCase("S"))
            tax = income * 0.25;
        else
            tax = income * 0.20;
    }

    public void display() {
        System.out.println(firstName + " " + lastName);
        System.out.println("SSN: " + ssn);
        System.out.println("Income: $" + income);
        System.out.println("Tax: $" + tax);
    }
}