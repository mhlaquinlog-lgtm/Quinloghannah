import java.util.Scanner;

public class PigLatin {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a word: ");
        String word = input.nextLine();

        String vowels = "aeiou";

        if(vowels.indexOf(word.charAt(0)) >= 0)
            System.out.println(word + "ay");
        else {
            int index = 0;
            while(index < word.length() &&
                  vowels.indexOf(word.charAt(index)) < 0)
                index++;

            System.out.println(word.substring(index) +
                               word.substring(0, index) + "ay");
        }
    }
}