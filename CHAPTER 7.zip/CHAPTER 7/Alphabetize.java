import java.util.Scanner;

public class Alphabetize {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        String a = input.nextLine();
        String b = input.nextLine();
        String c = input.nextLine();

        if(a.compareToIgnoreCase(b) <= 0 &&
           b.compareToIgnoreCase(c) <= 0)
            System.out.println("In alphabetical order");
        else
            System.out.println("Not in alphabetical order");
    }
}