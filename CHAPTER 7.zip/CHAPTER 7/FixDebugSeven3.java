public class FixDebugSeven3 {
    public static void main(String[] args) {
        String text = "Programming";

        System.out.println(text.substring(0, 5));
    }
}