import java.util.Scanner;

public class PrepareTax {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String ssn;
        do {
            System.out.print("Enter SSN (999-99-9999): ");
            ssn = input.nextLine();
        } while(!ssn.matches("\\d{3}-\\d{2}-\\d{4}"));

        System.out.print("Last name: ");
        String last = input.nextLine();

        System.out.print("First name: ");
        String first = input.nextLine();

        System.out.print("Street address: ");
        String addr = input.nextLine();

        System.out.print("City: ");
        String city = input.nextLine();

        System.out.print("State: ");
        String state = input.nextLine();

        String zip;
        do {
            System.out.print("Zip (5 digits): ");
            zip = input.nextLine();
        } while(!zip.matches("\\d{5}"));

        double income;
        do {
            System.out.print("Annual income: ");
            income = input.nextDouble();
        } while(income < 0);

        input.nextLine();

        String status;
        do {
            System.out.print("Marital Status (S/M): ");
            status = input.nextLine();
        } while(!status.matches("[SsMm]"));

        TaxReturn tr = new TaxReturn(ssn, last, first,
                addr, city, state, zip, income, status);

        tr.display();
    }
}