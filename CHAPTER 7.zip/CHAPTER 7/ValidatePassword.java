import java.util.Scanner;

public class ValidatePassword {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String password;

        while(true) {
            System.out.print("Enter password: ");
            password = input.nextLine();

            int upper=0, lower=0, digit=0;

            for(char c : password.toCharArray()) {
                if(Character.isUpperCase(c)) upper++;
                if(Character.isLowerCase(c)) lower++;
                if(Character.isDigit(c)) digit++;
            }

            if(upper >=2 && lower >=2 && digit >=2) {
                System.out.println("Password accepted!");
                break;
            }
            else {
                System.out.println("Invalid password.");
                System.out.println("Need at least 2 uppercase, 2 lowercase, 2 digits.");
            }
        }
    }
}