public class FixDebugSeven4 {
    public static void main(String[] args) {
        String a = "apple";
        String b = "banana";

        if(a.compareTo(b) < 0)
            System.out.println("apple comes first");
        else
            System.out.println("banana comes first");
    }
}