import java.util.Scanner;

public class PhoneNumberFormat {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        while(true) {
            System.out.print("Enter 10-digit number (999 to stop): ");
            String number = input.nextLine();

            if(number.equals("999"))
                break;

            if(number.length() == 10 && number.matches("\\d+")) {
                System.out.println("(" + number.substring(0,3) + ") "
                        + number.substring(3,6) + "-"
                        + number.substring(6));
            } else {
                System.out.println("Error: Must enter exactly 10 digits.");
            }
        }
    }
}