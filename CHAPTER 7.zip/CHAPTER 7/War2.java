public class War2 {
    public static void main(String[] args) {

        Card player = new Card();
        Card computer = new Card();

        System.out.println("Player: " + player.getRank() + " of " + player.getSuit());
        System.out.println("Computer: " + computer.getRank() + " of " + computer.getSuit());

        if(player.getValue() > computer.getValue())
            System.out.println("Player wins!");
        else if(player.getValue() < computer.getValue())
            System.out.println("Computer wins!");
        else
            System.out.println("Tie!");
    }
}