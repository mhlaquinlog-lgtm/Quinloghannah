import java.util.Arrays;
import java.util.Scanner;

public class Alphabetize2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        String[] names = new String[3];

        for(int i = 0; i < 3; i++)
            names[i] = input.nextLine();

        Arrays.sort(names, String.CASE_INSENSITIVE_ORDER);

        for(String name : names)
            System.out.println(name);
    }
}