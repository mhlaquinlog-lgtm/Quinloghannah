import java.util.Scanner;

public class ConstructID {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter full name: ");
        String name = input.nextLine();

        System.out.print("Enter street address: ");
        String address = input.nextLine();

        String[] parts = name.split(" ");
        String id = "";

        for(String part : parts)
            id += Character.toUpperCase(part.charAt(0));

        String numbers = address.replaceAll("\\D", "");

        System.out.println("ID: " + id + numbers);
    }
}