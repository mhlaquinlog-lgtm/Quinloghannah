import java.util.Scanner;

public class SecretPhrase {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        String phrase = "Go Team";
        String hidden = phrase.replaceAll("[A-Za-z]", "*");

        while(!hidden.equals(phrase)) {

            System.out.println("Phrase: " + hidden);
            System.out.print("Guess a letter: ");
            char guess = input.nextLine().charAt(0);

            StringBuilder updated = new StringBuilder(hidden);

            for(int i = 0; i < phrase.length(); i++) {
                if(Character.toLowerCase(phrase.charAt(i)) ==
                        Character.toLowerCase(guess))
                    updated.setCharAt(i, phrase.charAt(i));
            }

            if(updated.toString().equals(hidden))
                System.out.println("Letter not found.");
            else
                hidden = updated.toString();
        }

        System.out.println("Congratulations! Phrase: " + phrase);
    }
}