import java.util.Scanner;

public class ThreeLetterAcronym {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter three words: ");
        String line = input.nextLine();

        String[] words = line.trim().split("\\s+");

        String acronym = "";

        for(int i = 0; i < words.length && i < 3; i++)
            acronym += Character.toUpperCase(words[i].charAt(0));

        System.out.println("Acronym: " + acronym);
    }
}