import java.util.Scanner;

public class RockPaperScissors2 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int playerWins = 0, computerWins = 0, ties = 0;

        for(int round = 1; round <= 10; round++) {

            String playerChoice;

            while(true) {
                System.out.print("Enter rock, paper, or scissors: ");
                playerChoice = input.nextLine().toLowerCase();

                if(playerChoice.length() >= 2) {
                    if(playerChoice.startsWith("ro")) { playerChoice = "rock"; break; }
                    if(playerChoice.startsWith("pa")) { playerChoice = "paper"; break; }
                    if(playerChoice.startsWith("sc")) { playerChoice = "scissors"; break; }
                }

                System.out.println("Invalid entry. Try again.");
            }

            String[] options = {"rock","paper","scissors"};
            String computerChoice = options[(int)(Math.random()*3)];

            System.out.println("Computer chose: " + computerChoice);

            if(playerChoice.equals(computerChoice))
                ties++;
            else if(
                    (playerChoice.equals("rock") && computerChoice.equals("scissors")) ||
                    (playerChoice.equals("paper") && computerChoice.equals("rock")) ||
                    (playerChoice.equals("scissors") && computerChoice.equals("paper"))
            )
                playerWins++;
            else
                computerWins++;
        }

        System.out.println("\nResults:");
        System.out.println("Player wins: " + playerWins);
        System.out.println("Computer wins: " + computerWins);
        System.out.println("Ties: " + ties);
    }
}