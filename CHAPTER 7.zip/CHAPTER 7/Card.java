import java.util.Random;

public class Card {

    private int value;
    private String suit;
    private String rank;

    public Card() {
        Random rand = new Random();
        setValue(rand.nextInt(13) + 1);

        String[] suits = {"Spades", "Hearts", "Diamonds", "Clubs"};
        suit = suits[rand.nextInt(4)];
    }

    public void setValue(int val) {
        if(val < 1 || val > 13)
            val = 1;

        value = val;

        switch(value) {
            case 1: rank = "Ace"; break;
            case 11: rank = "Jack"; break;
            case 12: rank = "Queen"; break;
            case 13: rank = "King"; break;
            default: rank = String.valueOf(value);
        }
    }

    public int getValue() { return value; }
    public String getSuit() { return suit; }
    public String getRank() { return rank; }
}