import java.util.Scanner;

public class BabyNameComparison {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        String n1, n2, n3;

        System.out.print("Enter first name: ");
        n1 = input.nextLine();

        System.out.print("Enter second name: ");
        n2 = input.nextLine();

        System.out.print("Enter third name: ");
        n3 = input.nextLine();

        System.out.println(n1 + " " + n2);
        System.out.println(n1 + " " + n3);
        System.out.println(n2 + " " + n1);
        System.out.println(n2 + " " + n3);
        System.out.println(n3 + " " + n1);
        System.out.println(n3 + " " + n2);
    }
}