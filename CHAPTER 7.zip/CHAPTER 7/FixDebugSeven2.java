public class FixDebugSeven2 {
    public static void main(String[] args) {
        String name = "Java";

        System.out.println("Length: " + name.length());
    }
}