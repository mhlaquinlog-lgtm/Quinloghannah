import java.util.Scanner;
import java.util.Random;

public class Eliza {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        String[] randomResponses = {
                "Please go on",
                "Tell me more",
                "Continue"
        };

        while(true) {
            System.out.print("You: ");
            String statement = input.nextLine();

            if(statement.equalsIgnoreCase("Goodbye"))
                break;

            String lower = statement.toLowerCase();

            if(lower.contains(" my ")) {
                int index = lower.indexOf(" my ") + 4;
                String noun = statement.substring(index);
                System.out.println("Eliza: Tell me more about your " + noun);
            }
            else if(lower.contains("love") || lower.contains("hate")) {
                System.out.println("Eliza: You seem to have strong feelings about that");
            }
            else {
                System.out.println("Eliza: " + randomResponses[rand.nextInt(3)]);
            }
        }
    }
}