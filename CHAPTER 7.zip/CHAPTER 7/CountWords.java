import java.util.Scanner;

public class CountWords {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a sentence: ");
        String sentence = input.nextLine().trim();

        if(sentence.isEmpty()) {
            System.out.println("Word count: 0");
            return;
        }

        String[] words = sentence.split("[ .,;?!-]+");
        System.out.println("Word count: " + words.length);
    }
}