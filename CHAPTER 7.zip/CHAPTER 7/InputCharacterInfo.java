import java.util.Scanner;

public class InputCharacterInfo {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a character: ");
        char aChar = input.next().charAt(0);

        System.out.println("The character is " + aChar);

        System.out.println(aChar + 
            (Character.isUpperCase(aChar) ? " is uppercase" : " is not uppercase"));

        System.out.println(aChar + 
            (Character.isLowerCase(aChar) ? " is lowercase" : " is not lowercase"));

        System.out.println("After toLowerCase(): " + Character.toLowerCase(aChar));
        System.out.println("After toUpperCase(): " + Character.toUpperCase(aChar));

        System.out.println(aChar +
            (Character.isLetterOrDigit(aChar) ? " is letter/digit" : " is neither letter nor digit"));

        System.out.println(aChar +
            (Character.isWhitespace(aChar) ? " is whitespace" : " is not whitespace"));
    }
}