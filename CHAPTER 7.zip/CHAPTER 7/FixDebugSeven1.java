public class FixDebugSeven1 {
    public static void main(String[] args) {
        String word = "Hello";

        if(word.equals("Hello"))
            System.out.println("Match found");
        else
            System.out.println("No match");
    }
}