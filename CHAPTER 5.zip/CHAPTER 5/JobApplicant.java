public class JobApplicant {
    private String name;
    private String phone;
    private boolean word;
    private boolean spread;
    private boolean data;
    private boolean graphics;

    public JobApplicant(String n, String p, boolean w, boolean s, boolean d, boolean g) {
        name = n;
        phone = p;
        word = w;
        spread = s;
        data = d;
        graphics = g;
    }

    public String getName() { return name; }
    public String getPhone() { return phone; }
    public boolean getWord() { return word; }
    public boolean getSpread() { return spread; }
    public boolean getData() { return data; }
    public boolean getGraphics() { return graphics; }
}