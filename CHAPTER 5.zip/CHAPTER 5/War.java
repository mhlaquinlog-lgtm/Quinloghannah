import java.util.Random;

public class War {
    public static void main(String[] args) {
        Random rand = new Random();

        int player = rand.nextInt(13) + 1;
        int computer = rand.nextInt(13) + 1;

        System.out.println("Player card value: " + player);
        System.out.println("Computer card value: " + computer);

        if(player > computer)
            System.out.println("Player wins!");
        else if(player < computer)
            System.out.println("Computer wins!");
        else
            System.out.println("It's a tie!");
    }
}