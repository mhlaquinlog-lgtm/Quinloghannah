public class Automobile {
    private int id;
    private String make;
    private String model;
    private String color;
    private int year;
    private int mpg;

    public Automobile(int i,String mk,String md,String c,int y,int m) {
        setId(i);
        make = mk;
        model = md;
        color = c;
        setYear(y);
        setMpg(m);
    }

    public void setId(int i) {
        if(i >=0 && i <=9999) id = i;
        else id = 0;
    }

    public void setYear(int y) {
        if(y >=2000 && y <=2017) year = y;
        else year = 0;
    }

    public void setMpg(int m) {
        if(m >=10 && m <=60) mpg = m;
        else mpg = 0;
    }

    public int getId(){ return id; }
    public int getYear(){ return year; }
    public int getMpg(){ return mpg; }
    public String getMake(){ return make; }
    public String getModel(){ return model; }
    public String getColor(){ return color; }
}