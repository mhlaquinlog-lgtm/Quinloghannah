public class TestJobApplicants {

    public static boolean isQualified(JobApplicant a) {
        int skills = 0;
        if(a.getWord()) skills++;
        if(a.getSpread()) skills++;
        if(a.getData()) skills++;
        if(a.getGraphics()) skills++;

        return skills >= 3;
    }

    public static void main(String[] args) {
        JobApplicant a1 = new JobApplicant("Anna","12345",true,true,true,false);
        JobApplicant a2 = new JobApplicant("Ben","67890",true,false,false,true);

        JobApplicant[] list = {a1,a2};

        for(JobApplicant a : list) {
            if(isQualified(a))
                System.out.println(a.getName() + " is Qualified.");
            else
                System.out.println(a.getName() + " is Not Qualified.");
        }
    }
}