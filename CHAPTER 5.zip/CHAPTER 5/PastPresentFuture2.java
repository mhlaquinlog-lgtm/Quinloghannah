import java.util.Scanner;
import java.time.LocalDate;

public class PastPresentFuture2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter month: ");
        int month = input.nextInt();

        System.out.print("Enter day: ");
        int day = input.nextInt();

        System.out.print("Enter year: ");
        int year = input.nextInt();

        LocalDate enteredDate = LocalDate.of(year, month, day);
        LocalDate today = LocalDate.now();

        if(enteredDate.isBefore(today))
            System.out.println("The date is in the past.");
        else if(enteredDate.isAfter(today))
            System.out.println("The date is in the future.");
        else
            System.out.println("The date is today.");
    }
}