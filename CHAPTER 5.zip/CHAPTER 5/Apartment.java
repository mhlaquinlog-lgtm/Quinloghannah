public class Apartment {
    private int number;
    private int bedrooms;
    private int baths;
    private double rent;

    public Apartment(int n,int b,int ba,double r) {
        number = n;
        bedrooms = b;
        baths = ba;
        rent = r;
    }

    public int getNumber(){ return number; }
    public int getBedrooms(){ return bedrooms; }
    public int getBaths(){ return baths; }
    public double getRent(){ return rent; }
}