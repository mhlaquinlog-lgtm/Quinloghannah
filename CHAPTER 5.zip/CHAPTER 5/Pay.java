import java.util.Scanner;

public class Pay {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        double rate = 0;
        double insurance = 0;
        double retirement = 0;

        System.out.print("Skill Level (1,2,3): ");
        int skill = input.nextInt();

        if(skill == 1) rate = 17.00;
        else if(skill == 2) rate = 20.00;
        else if(skill == 3) rate = 22.00;
        else {
            System.out.println("Invalid skill level.");
            return;
        }

        System.out.print("Hours worked: ");
        double hours = input.nextDouble();

        double regularPay = Math.min(hours, 40) * rate;
        double overtimePay = 0;

        if(hours > 40)
            overtimePay = (hours - 40) * rate * 1.5;

        double gross = regularPay + overtimePay;

        if(skill >= 2) {
            System.out.print("Insurance? (1-Yes 2-No): ");
            int ins = input.nextInt();
            if(ins == 1) insurance = 32.50;
        }

        if(skill == 3) {
            System.out.print("Retirement? (1-Yes 2-No): ");
            int ret = input.nextInt();
            if(ret == 1) retirement = gross * 0.03;
        }

        double deductions = insurance + retirement;

        System.out.println("Gross Pay: $" + gross);
        System.out.println("Deductions: $" + deductions);

        if(deductions > gross)
            System.out.println("Error: Deductions exceed gross pay.");
        else
            System.out.println("Net Pay: $" + (gross - deductions));
    }
}