public class Event {
    private int guests;
    private double pricePerGuest;
    private double totalPrice;

    private final double LOW_PRICE = 32;
    private final double HIGH_PRICE = 35;

    public void setGuests(int g) {
        guests = g;
        if(isLargeEvent())
            pricePerGuest = LOW_PRICE;
        else
            pricePerGuest = HIGH_PRICE;

        totalPrice = guests * pricePerGuest;
    }

    public boolean isLargeEvent() {
        return guests >= 50;
    }

    public int getGuests(){ return guests; }
    public double getPricePerGuest(){ return pricePerGuest; }
    public double getTotalPrice(){ return totalPrice; }
}