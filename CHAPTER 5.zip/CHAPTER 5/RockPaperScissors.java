import java.util.Scanner;
import java.util.Random;

public class RockPaperScissors {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        System.out.println("1-Rock  2-Paper  3-Scissors");
        System.out.print("Enter choice: ");
        int user = input.nextInt();

        int computer = rand.nextInt(3) + 1;

        System.out.println("Computer chose: " + computer);

        if(user == computer)
            System.out.println("Tie!");
        else if((user == 1 && computer == 3) ||
                (user == 2 && computer == 1) ||
                (user == 3 && computer == 2))
            System.out.println("You win!");
        else
            System.out.println("Computer wins!");
    }
}