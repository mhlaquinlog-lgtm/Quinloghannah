import java.util.Scanner;

public class CondoSales {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int price = 0;
        String view = "";

        System.out.print("Choose view (1-Park, 2-Golf Course, 3-Lake): ");
        int choice = input.nextInt();

        switch(choice) {
            case 1:
                view = "Park View";
                price = 150000;
                break;
            case 2:
                view = "Golf Course View";
                price = 170000;
                break;
            case 3:
                view = "Lake View";
                price = 210000;
                break;
            default:
                view = "Invalid selection";
                price = 0;
        }

        System.out.println("View: " + view);
        System.out.println("Price: $" + price);
    }
}