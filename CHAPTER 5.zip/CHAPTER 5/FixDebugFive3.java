public class FixDebugFive3 {
    public static void main(String[] args) {
        int x = 15;

        if(x >= 10 && x <= 20)
            System.out.println("Between 10 and 20");
        else
            System.out.println("Outside range");
    }
}