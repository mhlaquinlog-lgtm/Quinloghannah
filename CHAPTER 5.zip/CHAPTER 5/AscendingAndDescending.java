import java.util.Scanner;
import java.util.Arrays;

public class AscendingAndDescending {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] numbers = new int[3];

        for(int i = 0; i < 3; i++) {
            System.out.print("Enter integer " + (i + 1) + ": ");
            numbers[i] = input.nextInt();
        }

        Arrays.sort(numbers);

        System.out.println("Ascending Order:");
        for(int n : numbers)
            System.out.print(n + " ");

        System.out.println("\nDescending Order:");
        for(int i = numbers.length - 1; i >= 0; i--)
            System.out.print(numbers[i] + " ");
    }
}