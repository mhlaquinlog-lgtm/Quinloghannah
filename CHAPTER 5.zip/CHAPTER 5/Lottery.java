import java.util.Scanner;
import java.util.Random;

public class Lottery {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        int r1 = rand.nextInt(10);
        int r2 = rand.nextInt(10);
        int r3 = rand.nextInt(10);

        System.out.print("Enter first digit: ");
        int g1 = input.nextInt();
        System.out.print("Enter second digit: ");
        int g2 = input.nextInt();
        System.out.print("Enter third digit: ");
        int g3 = input.nextInt();

        int matches = 0;

        if(g1 == r1) matches++;
        if(g2 == r2) matches++;
        if(g3 == r3) matches++;

        System.out.println("Winning numbers: " + r1 + r2 + r3);

        if(matches == 3)
            System.out.println("You won $100!");
        else if(matches == 2)
            System.out.println("You won $50!");
        else if(matches == 1)
            System.out.println("You won $10!");
        else
            System.out.println("No win.");
    }
}