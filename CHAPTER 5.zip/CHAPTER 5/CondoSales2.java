import java.util.Scanner;

public class CondoSales2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int price = 0;

        System.out.print("Choose view (1-Park, 2-Golf Course, 3-Lake): ");
        int choice = input.nextInt();

        if(choice == 1) price = 150000;
        else if(choice == 2) price = 170000;
        else if(choice == 3) price = 210000;
        else {
            System.out.println("Invalid view selection.");
            price = 0;
        }

        if(price != 0) {
            System.out.print("Parking? (1-Garage, 2-Parking Space): ");
            int parking = input.nextInt();

            if(parking == 1)
                price += 5000;
            else if(parking != 2)
                System.out.println("Invalid parking option. No garage added.");
        }

        System.out.println("Final Price: $" + price);
    }
}