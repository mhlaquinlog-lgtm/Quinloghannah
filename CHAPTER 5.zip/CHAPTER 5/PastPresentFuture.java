import java.util.Scanner;
import java.time.LocalDate;

public class PastPresentFuture {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        LocalDate today = LocalDate.now();

        System.out.print("Enter month: ");
        int month = input.nextInt();

        System.out.print("Enter day: ");
        int day = input.nextInt();

        System.out.print("Enter year: ");
        int year = input.nextInt();

        if(year != today.getYear())
            System.out.println("Not this year.");
        else if(month < today.getMonthValue())
            System.out.println("Earlier month this year.");
        else if(month > today.getMonthValue())
            System.out.println("Later month this year.");
        else
            System.out.println("This month.");
    }
}