public class FixDebugFive4 {
    public static void main(String[] args) {
        int choice = 2;

        switch(choice) {
            case 1:
                System.out.println("Choice 1");
                break;
            case 2:
                System.out.println("Choice 2");
                break;
            default:
                System.out.println("Invalid choice");
        }
    }
}