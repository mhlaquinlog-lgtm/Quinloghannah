public class Rental {
    private int hours;
    private int minutes;
    private double price;

    public void setTime(int totalMinutes) {
        hours = totalMinutes / 60;
        minutes = totalMinutes % 60;

        if(minutes > 40)
            minutes = 40;

        price = (hours * 40) + minutes;
    }

    public int getHours(){ return hours; }
    public int getMinutes(){ return minutes; }
    public double getPrice(){ return price; }
}