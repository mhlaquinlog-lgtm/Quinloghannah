import java.util.Random;

public class TwoDice2 {
    public static void main(String[] args) {
        Random rand = new Random();

        int die1 = rand.nextInt(6) + 1;
        int die2 = rand.nextInt(6) + 1;

        System.out.println("Die 1: " + die1);
        System.out.println("Die 2: " + die2);

        if(die1 == die2)
            System.out.println("Same value!");
        else if(die1 > die2)
            System.out.println("First die is higher.");
        else
            System.out.println("Second die is higher.");
    }
}