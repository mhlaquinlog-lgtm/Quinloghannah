import java.util.Scanner;
import java.util.Random;

public class RandomGuess2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        int randomNumber = rand.nextInt(100) + 1;

        System.out.print("Guess a number (1-100): ");
        int guess = input.nextInt();

        if(guess == randomNumber)
            System.out.println("Correct!");
        else if(guess > randomNumber)
            System.out.println("Too high!");
        else
            System.out.println("Too low!");

        System.out.println("Random number was: " + randomNumber);
    }
}