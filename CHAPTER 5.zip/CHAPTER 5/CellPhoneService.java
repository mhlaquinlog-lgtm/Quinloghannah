import java.util.Scanner;

public class CellPhoneService {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Talk minutes: ");
        int minutes = input.nextInt();

        System.out.print("Text messages: ");
        int texts = input.nextInt();

        System.out.print("Gigabytes of data: ");
        int data = input.nextInt();

        if(data > 0) {
            if(data <= 2)
                System.out.println("Recommended Plan E - $79");
            else
                System.out.println("Recommended Plan F - $87");
        }
        else if(minutes < 500) {
            if(texts == 0)
                System.out.println("Recommended Plan A - $49");
            else
                System.out.println("Recommended Plan B - $55");
        }
        else {
            if(texts <= 100)
                System.out.println("Recommended Plan C - $61");
            else
                System.out.println("Recommended Plan D - $70");
        }
    }
}