public class DinnerPartyWithConstructor extends PartyWithConstructor {
    private int dinnerChoice;
}