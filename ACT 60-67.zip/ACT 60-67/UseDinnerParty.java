import java.util.*;

public class UseDinnerParty {
    public static void main(String[] args) {
        int guests;
        Party aParty = new Party();
        DinnerParty aDinnerParty = new DinnerParty();
        Scanner keyboard = new Scanner(System.in);

        System.out.print("Enter number of guests for the party >> ");
        guests = keyboard.nextInt();
        aParty.setGuests(guests);
        System.out.println("The party has " + aParty.getGuests() + " guests");
        aParty.displayInvitation();

        System.out.print("Enter number of guests for the dinner party >> ");
        guests = keyboard.nextInt();
        aDinnerParty.setGuests(guests);

        System.out.print("Enter the menu option -- 1 for chicken or 2 for beef >> ");
        int choice = keyboard.nextInt();
        aDinnerParty.setDinnerChoice(choice);
        aDinnerParty.displayDinnerInfo();
        aDinnerParty.displayInvitation();
    }
}