public class DinnerPartyWithConstructor2 extends PartyWithConstructor2 {
    private int dinnerChoice;

    public DinnerPartyWithConstructor2(int numGuests) {
        super(numGuests);
    }
}