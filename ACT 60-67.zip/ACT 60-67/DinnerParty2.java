public class DinnerParty2 extends Party {
    private int dinnerChoice;

    public void setDinnerChoice(int choice) {
        dinnerChoice = choice;
    }

    public int getDinnerChoice() {
        return dinnerChoice;
    }

    public void displayDinnerInfo() {
        System.out.println("The dinner party has " + getGuests() + " guests");
        System.out.println("Menu option " + dinnerChoice + " will be served");
    }

    @Override
    public void displayInvitation() {
        System.out.println("Please come to my dinner party!");
    }
}