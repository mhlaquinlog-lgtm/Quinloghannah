

import java.util.Scanner;

public class TestSpaService
{
   public static void main(String[] args)
   {
      Scanner keyboard = new Scanner(System.in);

      SpaService firstService = new SpaService();
      SpaService secondService = new SpaService();

      String service;
      double price;

      System.out.print("Enter service description >> ");
      service = keyboard.nextLine();
      System.out.print("Enter price >> ");
      price = keyboard.nextDouble();
      keyboard.nextLine(); // clear buffer

      firstService.setServiceDescription(service);
      firstService.setPrice(price);
-
      System.out.print("Enter service description >> ");
      service = keyboard.nextLine();
      System.out.print("Enter price >> ");
      price = keyboard.nextDouble();

      secondService.setServiceDescription(service);
      secondService.setPrice(price);

      System.out.println("\nFirst service details:");
      System.out.println(firstService.getServiceDescription() +
                         " $" + firstService.getPrice());

      System.out.println("\nSecond service details:");
      System.out.println(secondService.getServiceDescription() +
                         " $" + secondService.getPrice());
   }
}
