public class Salesperson {
    private int idNumber;
    private double sales;

    public Salesperson(int idNumber, double sales) {
        this.idNumber = idNumber;
        this.sales = sales;
    }

    public int getIdNumber() { return idNumber; }
    public double getSales() { return sales; }

    public void setIdNumber(int idNumber) { this.idNumber = idNumber; }
    public void setSales(double sales) { this.sales = sales; }

    @Override
    public String toString() {
        return String.format("ID: %4d | Sales: $%.2f", idNumber, sales);
    }
}
