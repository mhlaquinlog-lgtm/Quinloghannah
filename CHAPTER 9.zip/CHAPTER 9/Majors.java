import java.util.Scanner;

public class Majors {
    enum Major { ACC, CHEM, CIS, ENG, HIS, PHYS }

    public static void main(String[] args) {
        System.out.println("Available majors:");
        for (Major m : Major.values()) System.out.println("  " + m);

        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter your major: ");
        String input = sc.nextLine().trim().toUpperCase();

        try {
            Major chosen = Major.valueOf(input);
            String division = switch (chosen) {
                case ACC, CIS   -> "Business Division";
                case CHEM, PHYS -> "Science Division";
                case ENG, HIS   -> "Humanities Division";
            };
            System.out.println(chosen + " belongs to the " + division + ".");
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid major entered.");
        }
        sc.close();
    }
}
