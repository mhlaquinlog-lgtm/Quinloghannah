public class Recording {
    private String title;
    private String artist;
    private int playingTime; // in seconds

    public Recording(String title, String artist, int playingTime) {
        this.title = title;
        this.artist = artist;
        this.playingTime = playingTime;
    }

    public String getTitle() { return title; }
    public String getArtist() { return artist; }
    public int getPlayingTime() { return playingTime; }

    public void setTitle(String title) { this.title = title; }
    public void setArtist(String artist) { this.artist = artist; }
    public void setPlayingTime(int playingTime) { this.playingTime = playingTime; }

    @Override
    public String toString() {
        return String.format("Title: %-20s | Artist: %-20s | Time: %d sec",
                title, artist, playingTime);
    }
}
