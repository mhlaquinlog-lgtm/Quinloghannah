import java.util.Scanner;

public class MorgansBonuses {
    // Bonus table: rows = weeks (0:<2, 1:2-4, 2:5+), cols = reviews (0:<3, 1:3-6, 2:7+)
    static final int[][] BONUS_TABLE = {
        {0,    100,  200},
        {100,  300,  500},
        {200,  500, 1000}
    };

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.print("\nEnter full weeks worked (or -1 to quit): ");
            int weeks = Integer.parseInt(sc.nextLine().trim());
            if (weeks == -1) break;

            System.out.print("Enter number of positive online reviews: ");
            int reviews = Integer.parseInt(sc.nextLine().trim());

            int weekIdx = weeks < 2 ? 0 : weeks <= 4 ? 1 : 2;
            int revIdx  = reviews < 3 ? 0 : reviews <= 6 ? 1 : 2;

            System.out.printf("Bonus: $%,d%n", BONUS_TABLE[weekIdx][revIdx]);
        }

        System.out.println("Goodbye!");
        sc.close();
    }
}
