import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class RecordingSort {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Recording[] recordings = new Recording[5];

        for (int i = 0; i < 5; i++) {
            System.out.println("\nRecording " + (i + 1) + ":");
            System.out.print("  Title: ");
            String title = sc.nextLine().trim();
            System.out.print("  Artist: ");
            String artist = sc.nextLine().trim();
            System.out.print("  Playing time (seconds): ");
            int time = Integer.parseInt(sc.nextLine().trim());
            recordings[i] = new Recording(title, artist, time);
        }

        System.out.println("\nSort by: 1=Title  2=Artist  3=Playing Time");
        System.out.print("Enter choice: ");
        int choice = Integer.parseInt(sc.nextLine().trim());

        switch (choice) {
            case 1 -> Arrays.sort(recordings, Comparator.comparing(Recording::getTitle));
            case 2 -> Arrays.sort(recordings, Comparator.comparing(Recording::getArtist));
            case 3 -> Arrays.sort(recordings, Comparator.comparingInt(Recording::getPlayingTime));
            default -> System.out.println("Invalid choice, no sort applied.");
        }

        System.out.println("\nSorted Recordings:");
        for (Recording r : recordings) System.out.println(r);
        sc.close();
    }
}
