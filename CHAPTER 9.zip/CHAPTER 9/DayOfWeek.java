import java.util.Scanner;

public class DayOfWeek {
    enum Day { SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY }

    public static void main(String[] args) {
        System.out.println("Days of the week:");
        for (Day d : Day.values()) System.out.println("  " + d);

        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter a day: ");
        String input = sc.nextLine().trim().toUpperCase();

        try {
            Day chosen = Day.valueOf(input);
            String hours = switch (chosen) {
                case SUNDAY    -> "11:00 AM - 5:00 PM";
                case SATURDAY  -> "10:00 AM - 6:00 PM";
                default        -> "9:00 AM - 9:00 PM";
            };
            System.out.println("Business hours on " + chosen + ": " + hours);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid day entered.");
        }
        sc.close();
    }
}
