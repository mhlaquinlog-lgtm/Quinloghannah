import java.util.Arrays;
import java.util.Scanner;

public class StringSort2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] words = new String[20];
        int count = 0;

        System.out.println("Enter up to 20 strings (type 'done' to stop):");
        while (count < 20) {
            System.out.print("Enter string " + (count + 1) + ": ");
            String input = sc.nextLine().trim();
            if (input.equalsIgnoreCase("done")) break;
            words[count++] = input;
        }

        if (count == 0) {
            System.out.println("No strings entered.");
            return;
        }

        String[] entered = Arrays.copyOf(words, count);
        Arrays.sort(entered);

        System.out.println("\nStrings in ascending order:");
        for (String s : entered) {
            System.out.println(s);
        }
        sc.close();
    }
}
