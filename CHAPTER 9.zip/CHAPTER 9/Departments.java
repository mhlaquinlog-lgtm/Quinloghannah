import java.util.Scanner;

public class Departments {
    public static void main(String[] args) {
        String[][] data = {
            {"Marketing",   "Alice Reyes"},
            {"Engineering", "Bob Santos"},
            {"Finance",     "Carol Tan"},
            {"HR",          "David Lim"},
            {"Operations",  "Eva Cruz"}
        };

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a department name: ");
        String input = sc.nextLine().trim();

        boolean found = false;
        for (String[] row : data) {
            if (row[0].equalsIgnoreCase(input)) {
                System.out.println("Supervisor: " + row[1]);
                found = true;
                break;
            }
        }
        if (!found) System.out.println("Department not found.");
        sc.close();
    }
}
