import java.util.Arrays;
import java.util.Scanner;

public class MeanMedian {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] nums = new int[5];

        System.out.println("Enter 5 integers:");
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter integer " + (i + 1) + ": ");
            nums[i] = sc.nextInt();
        }

        Arrays.sort(nums);

        double mean = 0;
        for (int n : nums) mean += n;
        mean /= 5;

        double median = nums[2]; // middle of 5

        System.out.print("\nValues: ");
        for (int n : nums) System.out.print(n + " ");
        System.out.printf("\nMean: %.2f%n", mean);
        System.out.printf("Median: %.1f%n", median);
        sc.close();
    }
}
