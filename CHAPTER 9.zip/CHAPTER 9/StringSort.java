import java.util.Arrays;

public class StringSort {
    public static void main(String[] args) {
        String[] words = {"banana", "apple", "mango", "cherry", "date",
                          "elderberry", "fig", "grape", "honeydew", "kiwi",
                          "lemon", "melon", "nectarine", "orange", "papaya",
                          "quince", "raspberry", "strawberry", "tangerine", "ugli"};

        Arrays.sort(words);

        System.out.println("Strings in ascending order:");
        for (String s : words) {
            System.out.println(s);
        }
    }
}
