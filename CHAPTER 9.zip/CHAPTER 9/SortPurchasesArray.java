import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class SortPurchasesArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Purchase[] purchases = new Purchase[5];

        for (int i = 0; i < 5; i++) {
            System.out.println("\nPurchase " + (i + 1) + ":");
            System.out.print("  Invoice Number: ");
            int inv = Integer.parseInt(sc.nextLine().trim());
            System.out.print("  Sale Amount: $");
            double amt = Double.parseDouble(sc.nextLine().trim());
            purchases[i] = new Purchase(inv, amt);
        }

        String sortChoice;
        do {
            System.out.println("\nSort by: 1=Invoice Number  2=Sale Amount  0=Quit");
            System.out.print("Enter choice: ");
            sortChoice = sc.nextLine().trim();

            switch (sortChoice) {
                case "1" -> {
                    Arrays.sort(purchases, Comparator.comparingInt(Purchase::getInvoiceNumber));
                    display(purchases);
                }
                case "2" -> {
                    Arrays.sort(purchases, Comparator.comparingDouble(Purchase::getSaleAmount));
                    display(purchases);
                }
                case "0" -> System.out.println("Exiting.");
                default  -> System.out.println("Invalid choice.");
            }
        } while (!sortChoice.equals("0"));
        sc.close();
    }

    static void display(Purchase[] p) {
        System.out.println("\nPurchases:");
        for (Purchase pur : p) System.out.println(pur);
    }
}
