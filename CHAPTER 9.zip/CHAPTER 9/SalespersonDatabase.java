import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class SalespersonDatabase {
    static final int MAX = 20;
    static Salesperson[] db = new Salesperson[MAX];
    static boolean[] active = new boolean[MAX];
    static int count = 0;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String choice;

        do {
            System.out.println("\n1=Add  2=Delete  3=Change  4=Quit");
            System.out.print("Enter choice: ");
            choice = sc.nextLine().trim();

            switch (choice) {
                case "1" -> addRecord(sc);
                case "2" -> deleteRecord(sc);
                case "3" -> changeRecord(sc);
                case "4" -> System.out.println("Goodbye!");
                default  -> System.out.println("Invalid choice.");
            }

            if (!choice.equals("4")) displayDatabase();

        } while (!choice.equals("4"));
        sc.close();
    }

    static void addRecord(Scanner sc) {
        if (count >= MAX) { System.out.println("Database is full."); return; }
        System.out.print("Enter ID: ");
        int id = Integer.parseInt(sc.nextLine().trim());
        if (findById(id) >= 0) { System.out.println("ID already exists."); return; }
        System.out.print("Enter sales: $");
        double sales = Double.parseDouble(sc.nextLine().trim());
        db[count] = new Salesperson(id, sales);
        active[count] = true;
        count++;
        System.out.println("Record added.");
    }

    static void deleteRecord(Scanner sc) {
        if (count == 0) { System.out.println("Database is empty."); return; }
        System.out.print("Enter ID to delete: ");
        int id = Integer.parseInt(sc.nextLine().trim());
        int idx = findById(id);
        if (idx < 0) { System.out.println("ID not found."); return; }
        active[idx] = false;
        System.out.println("Record deleted.");
    }

    static void changeRecord(Scanner sc) {
        if (count == 0) { System.out.println("Database is empty."); return; }
        System.out.print("Enter ID to change: ");
        int id = Integer.parseInt(sc.nextLine().trim());
        int idx = findById(id);
        if (idx < 0) { System.out.println("ID not found."); return; }
        System.out.print("Enter new sales: $");
        double newSales = Double.parseDouble(sc.nextLine().trim());
        db[idx].setSales(newSales);
        System.out.println("Record updated.");
    }

    static int findById(int id) {
        for (int i = 0; i < count; i++)
            if (active[i] && db[i].getIdNumber() == id) return i;
        return -1;
    }

    static void displayDatabase() {
        // collect active records
        Salesperson[] active_list = new Salesperson[count];
        int n = 0;
        for (int i = 0; i < count; i++)
            if (active[i]) active_list[n++] = db[i];

        Salesperson[] sorted = Arrays.copyOf(active_list, n);
        Arrays.sort(sorted, Comparator.comparingInt(Salesperson::getIdNumber));

        System.out.println("\n--- Database (sorted by ID) ---");
        if (n == 0) System.out.println("(empty)");
        else for (Salesperson s : sorted) System.out.println(s);
    }
}
