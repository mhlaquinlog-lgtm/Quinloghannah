import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class SalespersonSort {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Salesperson[] people = new Salesperson[7];

        for (int i = 0; i < 7; i++) {
            System.out.println("\nSalesperson " + (i + 1) + ":");
            System.out.print("  ID Number: ");
            int id = Integer.parseInt(sc.nextLine().trim());
            System.out.print("  Sales value: $");
            double sales = Double.parseDouble(sc.nextLine().trim());
            people[i] = new Salesperson(id, sales);
        }

        System.out.println("\nSort by: 1=ID Number  2=Sales Value");
        System.out.print("Enter choice: ");
        int choice = Integer.parseInt(sc.nextLine().trim());

        switch (choice) {
            case 1 -> Arrays.sort(people, Comparator.comparingInt(Salesperson::getIdNumber));
            case 2 -> Arrays.sort(people, Comparator.comparingDouble(Salesperson::getSales));
            default -> System.out.println("Invalid choice, no sort applied.");
        }

        System.out.println("\nSalespersons:");
        for (Salesperson s : people) System.out.println(s);
        sc.close();
    }
}
