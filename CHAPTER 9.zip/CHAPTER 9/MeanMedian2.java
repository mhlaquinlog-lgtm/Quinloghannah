import java.util.Arrays;
import java.util.Scanner;

public class MeanMedian2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] nums = new int[20];
        int count = 0;

        System.out.println("Enter up to 20 integers (-999 to stop):");
        while (count < 20) {
            System.out.print("Enter integer: ");
            int val = sc.nextInt();
            if (val == -999) break;
            nums[count++] = val;
        }

        if (count == 0) {
            System.out.println("No values entered.");
            return;
        }

        int[] entered = Arrays.copyOf(nums, count);
        Arrays.sort(entered);

        double mean = 0;
        for (int n : entered) mean += n;
        mean /= count;

        double median;
        if (count % 2 == 1) {
            median = entered[count / 2];
        } else {
            median = (entered[count / 2 - 1] + entered[count / 2]) / 2.0;
        }

        System.out.print("\nSorted values: ");
        for (int n : entered) System.out.print(n + " ");
        System.out.printf("\nMean: %.2f%n", mean);
        System.out.printf("Median: %.2f%n", median);
        sc.close();
    }
}
