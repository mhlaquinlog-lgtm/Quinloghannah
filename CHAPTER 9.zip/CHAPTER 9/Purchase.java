public class Purchase {
    private int invoiceNumber;
    private double saleAmount;
    private double salesTax;

    public Purchase(int invoiceNumber, double saleAmount) {
        this.invoiceNumber = invoiceNumber;
        this.saleAmount = saleAmount;
        this.salesTax = saleAmount * 0.07; // 7% tax
    }

    public int getInvoiceNumber() { return invoiceNumber; }
    public double getSaleAmount() { return saleAmount; }
    public double getSalesTax() { return salesTax; }

    public void setInvoiceNumber(int invoiceNumber) { this.invoiceNumber = invoiceNumber; }
    public void setSaleAmount(double saleAmount) {
        this.saleAmount = saleAmount;
        this.salesTax = saleAmount * 0.07;
    }

    @Override
    public String toString() {
        return String.format("Invoice #%4d | Sale: $%8.2f | Tax: $%6.2f",
                invoiceNumber, saleAmount, salesTax);
    }
}
