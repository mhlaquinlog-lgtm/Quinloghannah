import javax.swing.JOptionPane;

public class JOptionPaneDemo
{
    public static void main(String[] args)
    {
        JOptionPane.showMessageDialog(null, "Welcome to Java Programming!");
    }
}
