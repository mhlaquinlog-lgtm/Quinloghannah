// MovieQuote.java
public class MovieQuote {
    public static void main(String[] args) {
        System.out.println("May the Force be with you.");
    }
}