public class Package {
    private double weight;      // ounces
    private char   shippingMethod;
    protected double shippingCost;

    public Package(double weight, char shippingMethod) {
        this.weight         = weight;
        this.shippingMethod = Character.toUpperCase(shippingMethod);
        calculateCost();
    }

    protected void calculateCost() {
        // Cost table based on weight (oz) and method
        // Air (A):  0-8oz=$2.00, 9-16oz=$3.00, 17-32oz=$4.50, 33+oz=$6.00
        // Truck(T): 0-8oz=$1.00, 9-16oz=$1.50, 17-32oz=$2.50, 33+oz=$3.50
        // Mail (M): 0-8oz=$0.50, 9-16oz=$0.80, 17-32oz=$1.25, 33+oz=$2.00
        switch (shippingMethod) {
            case 'A' -> shippingCost = weight <= 8 ? 2.00 : weight <= 16 ? 3.00 : weight <= 32 ? 4.50 : 6.00;
            case 'T' -> shippingCost = weight <= 8 ? 1.00 : weight <= 16 ? 1.50 : weight <= 32 ? 2.50 : 3.50;
            case 'M' -> shippingCost = weight <= 8 ? 0.50 : weight <= 16 ? 0.80 : weight <= 32 ? 1.25 : 2.00;
            default  -> { System.out.println("Invalid method. Defaulting to Mail."); shippingCost = 0.50; }
        }
    }

    public double getWeight()         { return weight; }
    public char getShippingMethod()   { return shippingMethod; }
    public double getShippingCost()   { return shippingCost; }

    public void display() {
        System.out.printf("Weight: %.1f oz | Method: %c | Shipping Cost: $%.2f%n",
                weight, shippingMethod, shippingCost);
    }
}
