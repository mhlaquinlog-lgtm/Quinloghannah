public class DemoHSBaseballGame {
    public static void main(String[] args) {
        HighSchoolBaseballGame game = new HighSchoolBaseballGame("Wildcats", "Bulldogs");

        int[] w = {1, 0, 2, 0, 0, 3, 1};
        int[] b = {0, 2, 0, 1, 0, 0, 2};
        for (int i = 0; i < 7; i++) {
            game.setScore1(w[i], i);
            game.setScore2(b[i], i);
        }

        game.displayScores();
        System.out.println("Result: " + game.determineWinner());

        // Demonstrate locked innings
        System.out.println("\nTrying to set inning 8 (doesn't exist in HS game):");
        game.setScore1(5, 7); // Error
    }
}
