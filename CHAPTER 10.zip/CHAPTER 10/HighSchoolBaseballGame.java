public class HighSchoolBaseballGame extends BaseballGame {
    private static final int HS_INNINGS = 7;

    public HighSchoolBaseballGame(String team1, String team2) {
        super(team1, team2, HS_INNINGS);
    }

    @Override
    protected boolean validInning(int inning) {
        return inning >= 0 && inning < HS_INNINGS;
    }
}
