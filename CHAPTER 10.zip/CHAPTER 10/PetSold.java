public class PetSold extends ItemSold {
    private boolean vaccinated;
    private boolean neutered;
    private boolean housebroken;

    public PetSold(int invoiceNumber, String description, double price,
                   boolean vaccinated, boolean neutered, boolean housebroken) {
        super(invoiceNumber, description, price);
        this.vaccinated  = vaccinated;
        this.neutered    = neutered;
        this.housebroken = housebroken;
    }

    public boolean isVaccinated()           { return vaccinated; }
    public boolean isNeutered()             { return neutered; }
    public boolean isHousebroken()          { return housebroken; }

    public void setVaccinated(boolean v)    { this.vaccinated = v; }
    public void setNeutered(boolean n)      { this.neutered = n; }
    public void setHousebroken(boolean h)   { this.housebroken = h; }

    @Override
    public String toString() {
        return super.toString() +
               String.format(" | Vaccinated: %b | Neutered: %b | Housebroken: %b",
                       vaccinated, neutered, housebroken);
    }
}
