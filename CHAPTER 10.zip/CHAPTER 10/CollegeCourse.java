public class CollegeCourse {
    private String department;
    private int    courseNumber;
    private int    credits;
    private double fee;

    public CollegeCourse(String department, int courseNumber, int credits) {
        this.department   = department;
        this.courseNumber = courseNumber;
        this.credits      = credits;
        this.fee          = credits * 120.0;
    }

    public String getDepartment()  { return department; }
    public int getCourseNumber()   { return courseNumber; }
    public int getCredits()        { return credits; }
    public double getFee()         { return fee; }

    public void display() {
        System.out.printf("Department: %s | Course: %d | Credits: %d | Fee: $%.2f%n",
                department, courseNumber, credits, fee);
    }
}
