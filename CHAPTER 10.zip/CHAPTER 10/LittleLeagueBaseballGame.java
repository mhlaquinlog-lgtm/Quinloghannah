public class LittleLeagueBaseballGame extends BaseballGame {
    private static final int LL_INNINGS = 6;

    public LittleLeagueBaseballGame(String team1, String team2) {
        super(team1, team2, LL_INNINGS);
    }

    @Override
    protected boolean validInning(int inning) {
        return inning >= 0 && inning < LL_INNINGS;
    }
}
