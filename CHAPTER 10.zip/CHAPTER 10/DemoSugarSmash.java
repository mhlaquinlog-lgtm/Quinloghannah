public class DemoSugarSmash {
    public static void main(String[] args) {
        System.out.println("=== Free Player ===");
        SugarSmashPlayer p1 = new SugarSmashPlayer(101, "StarPlayer");
        p1.setScore(250, 0);  // Level 1
        p1.setScore(180, 1);  // Level 2 - should work (L1 >= 100)
        p1.setScore(90,  2);  // Error: L2 score is only 180 which is fine, but L1 and L2 both need >=100
        // Actually level 2 requires levels 0 and 1 both >=100: 250 and 180 both ok
        p1.setScore(200, 2);  // Level 3
        System.out.println(p1);

        System.out.println("\nTrying to skip level:");
        p1.setScore(150, 5);  // Error: levels 3 and 4 not set

        System.out.println("\nTrying out-of-range level:");
        p1.setScore(100, 10); // Error: out of range

        System.out.println("\n=== Premium Player ===");
        PremiumSugarSmashPlayer p2 = new PremiumSugarSmashPlayer(202, "UltraGamer");
        // Fill first 10 levels to unlock premium range
        for (int i = 0; i < 10; i++) p2.setScore(150, i);
        p2.setScore(300, 10); // Level 11 - premium only
        p2.setScore(275, 11); // Level 12
        System.out.println(p2);
    }
}
