public class BaseballGame {
    protected String team1;
    protected String team2;
    protected int[] scores1;
    protected int[] scores2;
    protected int innings;
    protected boolean[] inningSet1;
    protected boolean[] inningSet2;

    public BaseballGame(String team1, String team2, int innings) {
        this.team1    = team1;
        this.team2    = team2;
        this.innings  = innings;
        scores1    = new int[innings];
        scores2    = new int[innings];
        inningSet1 = new boolean[innings];
        inningSet2 = new boolean[innings];
    }

    public String getTeam1() { return team1; }
    public String getTeam2() { return team2; }

    public int getScore1(int inning) {
        if (!validInning(inning)) { System.out.println("Error: Invalid inning."); return -1; }
        return scores1[inning];
    }

    public int getScore2(int inning) {
        if (!validInning(inning)) { System.out.println("Error: Invalid inning."); return -1; }
        return scores2[inning];
    }

    public void setScore1(int score, int inning) {
        if (!validInning(inning)) { System.out.println("Error: Invalid inning."); return; }
        if (!allPreviousSet(inningSet1, inning)) {
            System.out.println("Error: Previous innings for " + team1 + " not set yet.");
            return;
        }
        scores1[inning]    = score;
        inningSet1[inning] = true;
    }

    public void setScore2(int score, int inning) {
        if (!validInning(inning)) { System.out.println("Error: Invalid inning."); return; }
        if (!allPreviousSet(inningSet2, inning)) {
            System.out.println("Error: Previous innings for " + team2 + " not set yet.");
            return;
        }
        scores2[inning]    = score;
        inningSet2[inning] = true;
    }

    protected boolean validInning(int inning) {
        return inning >= 0 && inning < innings;
    }

    private boolean allPreviousSet(boolean[] set, int inning) {
        for (int i = 0; i < inning; i++) if (!set[i]) return false;
        return true;
    }

    public String determineWinner() {
        int total1 = 0, total2 = 0;
        for (int s : scores1) total1 += s;
        for (int s : scores2) total2 += s;
        if (total1 > total2)      return team1 + " wins! (" + total1 + " - " + total2 + ")";
        else if (total2 > total1) return team2 + " wins! (" + total2 + " - " + total1 + ")";
        else                      return "It's a tie! (" + total1 + " - " + total2 + ")";
    }

    public void displayScores() {
        System.out.printf("%-20s", "Inning:");
        for (int i = 1; i <= innings; i++) System.out.printf("%4d", i);
        System.out.println();
        System.out.printf("%-20s", team1 + ":");
        for (int s : scores1) System.out.printf("%4d", s);
        System.out.println();
        System.out.printf("%-20s", team2 + ":");
        for (int s : scores2) System.out.printf("%4d", s);
        System.out.println();
    }
}
