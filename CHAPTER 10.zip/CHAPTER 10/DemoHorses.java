public class DemoHorses {
    public static void main(String[] args) {
        Horse h = new Horse("Bella", "Brown", 2018);
        System.out.println("--- Horse ---");
        System.out.println(h);

        h.setName("Daisy");
        h.setColor("White");
        h.setBirthYear(2020);
        System.out.println("After setters: " + h);

        System.out.println("\n--- RaceHorse ---");
        RaceHorse rh = new RaceHorse("Thunder", "Black", 2016, 12);
        System.out.println(rh);

        rh.setRacesCompeted(15);
        System.out.println("After updating races: " + rh);
    }
}
