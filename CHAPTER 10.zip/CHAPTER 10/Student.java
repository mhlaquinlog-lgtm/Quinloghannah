import java.util.Scanner;

public class Student extends Person {
    private String major;
    private double gpa;

    public Student() { super(); }

    public String getMajor() { return major; }
    public double getGpa()   { return gpa; }

    public void setMajor(String m) { major = m; }
    public void setGpa(double g)   { gpa = g; }

    @Override
    public void inputData(Scanner sc) {
        super.inputData(sc);
        System.out.print("  Major: ");  major = sc.nextLine().trim();
        System.out.print("  GPA: ");    gpa   = Double.parseDouble(sc.nextLine().trim());
    }

    @Override
    public void display() {
        super.display();
        System.out.println("  Major: " + major + " | GPA: " + gpa);
    }
}
