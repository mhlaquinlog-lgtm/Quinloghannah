public class DemoRocks {
    public static void main(String[] args) {
        Rock unclassified  = new Rock(1000, 50.0);
        IgneousRock igr    = new IgneousRock(1001, 120.5);
        SedimentaryRock sr = new SedimentaryRock(1002, 85.3);
        MetamorphicRock mr = new MetamorphicRock(1003, 200.0);

        System.out.println("=== Rock Samples ===");
        System.out.println(unclassified);
        System.out.println();
        System.out.println(igr);
        System.out.println("  Sample #: " + igr.getSampleNumber());
        System.out.println("  Weight  : " + igr.getWeight() + " g");
        System.out.println();
        System.out.println(sr);
        System.out.println();
        System.out.println(mr);
    }
}
