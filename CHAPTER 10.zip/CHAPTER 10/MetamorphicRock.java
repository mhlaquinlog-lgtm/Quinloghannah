public class MetamorphicRock extends Rock {
    public MetamorphicRock(int sampleNumber, double weight) {
        super(sampleNumber, weight);
        setDescription("Metamorphic - formed when existing rocks are transformed by heat and pressure deep in the earth (e.g., marble, slate).");
    }
}
