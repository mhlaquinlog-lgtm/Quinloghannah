public class DemoBaseballGame {
    public static void main(String[] args) {
        BaseballGame game = new BaseballGame("Eagles", "Tigers", 9);

        // Set all innings for both teams
        int[] e = {2, 0, 1, 0, 3, 0, 0, 1, 0};
        int[] t = {0, 1, 0, 2, 0, 0, 1, 0, 2};
        for (int i = 0; i < 9; i++) {
            game.setScore1(e[i], i);
            game.setScore2(t[i], i);
        }

        game.displayScores();
        System.out.println("Result: " + game.determineWinner());

        // Demonstrate error: skip an inning
        System.out.println("\nTrying to skip an inning:");
        BaseballGame g2 = new BaseballGame("A", "B", 9);
        g2.setScore1(3, 0);
        g2.setScore1(2, 2); // Error: inning 1 not set
    }
}
