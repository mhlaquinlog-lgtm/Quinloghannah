public class UsePackage {
    public static void main(String[] args) {
        System.out.println("=== Regular Packages ===");
        Package[] packages = {
            new Package(5,   'A'),
            new Package(12,  'T'),
            new Package(20,  'M'),
            new Package(40,  'A'),
        };
        for (Package p : packages) p.display();

        System.out.println("\n=== Insured Packages ===");
        InsuredPackage[] insured = {
            new InsuredPackage(5,   'A'),
            new InsuredPackage(12,  'T'),
            new InsuredPackage(20,  'M'),
        };
        for (InsuredPackage ip : insured) ip.display();
    }
}
