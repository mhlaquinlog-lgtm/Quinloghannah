import java.util.Scanner;

public class Faculty extends CollegeEmployee {
    private boolean tenured;

    public Faculty() { super(); }

    public boolean isTenured()          { return tenured; }
    public void setTenured(boolean t)   { tenured = t; }

    @Override
    public void inputData(Scanner sc) {
        super.inputData(sc);
        System.out.print("  Tenured (yes/no): ");
        tenured = sc.nextLine().trim().equalsIgnoreCase("yes");
    }

    @Override
    public void display() {
        super.display();
        System.out.println("  Tenured: " + (tenured ? "Yes" : "No"));
    }
}
