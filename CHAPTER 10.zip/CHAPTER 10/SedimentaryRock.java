public class SedimentaryRock extends Rock {
    public SedimentaryRock(int sampleNumber, double weight) {
        super(sampleNumber, weight);
        setDescription("Sedimentary - formed from compacted layers of sediment over time; often contains fossils (e.g., limestone, sandstone).");
    }
}
