import java.util.Scanner;

public class CollegeEmployee extends Person {
    private String ssn;
    private double annualSalary;
    private String department;

    public CollegeEmployee() { super(); }

    public String getSSN()           { return ssn; }
    public double getAnnualSalary()  { return annualSalary; }
    public String getDepartment()    { return department; }

    public void setSSN(String s)           { ssn = s; }
    public void setAnnualSalary(double d)  { annualSalary = d; }
    public void setDepartment(String s)    { department = s; }

    @Override
    public void inputData(Scanner sc) {
        super.inputData(sc);
        System.out.print("  SSN: ");            ssn          = sc.nextLine().trim();
        System.out.print("  Annual Salary: $"); annualSalary = Double.parseDouble(sc.nextLine().trim());
        System.out.print("  Department: ");     department   = sc.nextLine().trim();
    }

    @Override
    public void display() {
        super.display();
        System.out.println("  SSN: " + ssn + " | Salary: $" + annualSalary + " | Dept: " + department);
    }
}
