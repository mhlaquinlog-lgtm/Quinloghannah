public class DemoItemsAndPets {
    public static void main(String[] args) {
        System.out.println("--- ItemSold objects ---");
        ItemSold i1 = new ItemSold(1001, "Dog food bag", 29.99);
        ItemSold i2 = new ItemSold(1002, "Cat collar", 12.50);
        System.out.println(i1);
        System.out.println(i2);

        i1.setPrice(27.99);
        System.out.println("After price update: " + i1);

        System.out.println("\n--- PetSold objects ---");
        PetSold p1 = new PetSold(2001, "Golden Retriever puppy", 800.00, true, true, false);
        PetSold p2 = new PetSold(2002, "Persian cat", 600.00, true, false, true);
        System.out.println(p1);
        System.out.println(p2);

        p1.setHousebroken(true);
        System.out.println("After update: " + p1);
    }
}
