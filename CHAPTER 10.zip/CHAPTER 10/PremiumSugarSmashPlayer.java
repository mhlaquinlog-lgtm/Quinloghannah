public class PremiumSugarSmashPlayer extends SugarSmashPlayer {
    private static final int PREMIUM_LEVELS = 50; // 10 base + 40 extra
    private int[] premiumScores;

    public PremiumSugarSmashPlayer(int idNumber, String screenName) {
        super(idNumber, screenName);
        // Replace scores array with larger one
        this.scores = new int[PREMIUM_LEVELS];
        for (int i = 0; i < PREMIUM_LEVELS; i++) scores[i] = -1;
        this.premiumScores = this.scores;
    }

    @Override
    protected boolean validLevel(int level) {
        return level >= 0 && level < PREMIUM_LEVELS;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[PREMIUM] ID: ").append(getIdNumber())
          .append(" | Screen Name: ").append(getScreenName())
          .append(" | Total Levels: ").append(PREMIUM_LEVELS)
          .append("\nScores: ");
        for (int i = 0; i < PREMIUM_LEVELS; i++) {
            sb.append("L").append(i + 1).append("=")
              .append(scores[i] == -1 ? "N/A" : scores[i]);
            if (i < PREMIUM_LEVELS - 1) sb.append(", ");
        }
        return sb.toString();
    }
}
