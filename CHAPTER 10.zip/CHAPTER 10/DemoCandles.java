public class DemoCandles {
    public static void main(String[] args) {
        System.out.println("--- Candle ---");
        Candle c = new Candle("Red", 8);
        System.out.println(c);
        c.setColor("Blue");
        c.setHeight(10);
        System.out.println("After setters: " + c);

        System.out.println("\n--- ScentedCandle ---");
        ScentedCandle sc = new ScentedCandle("Purple", 6, "Lavender");
        System.out.println(sc);
        sc.setScent("Vanilla");
        sc.setHeight(9);
        System.out.println("After setters: " + sc);
    }
}
