import java.util.Scanner;

public class UseCourse {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter department (e.g. BIO, ENG, CIS): ");
        String dept = sc.nextLine().trim().toUpperCase();

        System.out.print("Enter course number: ");
        int courseNum = Integer.parseInt(sc.nextLine().trim());

        System.out.print("Enter credits: ");
        int credits = Integer.parseInt(sc.nextLine().trim());

        CollegeCourse course;
        if (dept.equals("BIO") || dept.equals("CHM") || dept.equals("CIS") || dept.equals("PHY")) {
            course = new LabCourse(dept, courseNum, credits);
        } else {
            course = new CollegeCourse(dept, courseNum, credits);
        }

        course.display();
        sc.close();
    }
}
