public class InsuredPackage extends Package {
    private double insuranceCost;

    public InsuredPackage(double weight, char shippingMethod) {
        super(weight, shippingMethod);
        calculateInsurance();
        shippingCost += insuranceCost; // add insurance to total
    }

    private void calculateInsurance() {
        // Insurance table based on shipping cost
        // <= $1.50 => +$0.75, <= $3.00 => +$1.25, <= $5.00 => +$2.00, > $5.00 => +$3.50
        double base = shippingCost; // before insurance added
        if      (base <= 1.50) insuranceCost = 0.75;
        else if (base <= 3.00) insuranceCost = 1.25;
        else if (base <= 5.00) insuranceCost = 2.00;
        else                   insuranceCost = 3.50;
    }

    public double getInsuranceCost() { return insuranceCost; }

    @Override
    public void display() {
        System.out.printf(
            "Weight: %.1f oz | Method: %c | Insurance: $%.2f | Total Cost: $%.2f%n",
            getWeight(), getShippingMethod(), insuranceCost, shippingCost);
    }
}
