import java.util.Scanner;

public class CollegeList {
    static final int MAX_EMP  = 4;
    static final int MAX_FAC  = 3;
    static final int MAX_STU  = 7;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CollegeEmployee[] employees = new CollegeEmployee[MAX_EMP];
        Faculty[]         faculty   = new Faculty[MAX_FAC];
        Student[]         students  = new Student[MAX_STU];
        int empCount = 0, facCount = 0, stuCount = 0;

        String choice;
        do {
            System.out.println("\nEnter type: C=CollegeEmployee  F=Faculty  S=Student  Q=Quit");
            System.out.print("Choice: ");
            choice = sc.nextLine().trim().toUpperCase();

            switch (choice) {
                case "C" -> {
                    if (empCount >= MAX_EMP) {
                        System.out.println("Error: Maximum " + MAX_EMP + " college employees already entered.");
                    } else {
                        employees[empCount] = new CollegeEmployee();
                        employees[empCount].inputData(sc);
                        empCount++;
                    }
                }
                case "F" -> {
                    if (facCount >= MAX_FAC) {
                        System.out.println("Error: Maximum " + MAX_FAC + " faculty already entered.");
                    } else {
                        faculty[facCount] = new Faculty();
                        faculty[facCount].inputData(sc);
                        facCount++;
                    }
                }
                case "S" -> {
                    if (stuCount >= MAX_STU) {
                        System.out.println("Error: Maximum " + MAX_STU + " students already entered.");
                    } else {
                        students[stuCount] = new Student();
                        students[stuCount].inputData(sc);
                        stuCount++;
                    }
                }
                case "Q" -> System.out.println("Generating report...");
                default  -> System.out.println("Invalid choice.");
            }
        } while (!choice.equals("Q"));

        // Display report
        System.out.println("\n========== COLLEGE EMPLOYEES ==========");
        if (empCount == 0) System.out.println("No college employees entered.");
        else for (int i = 0; i < empCount; i++) { employees[i].display(); System.out.println(); }

        System.out.println("========== FACULTY ==========");
        if (facCount == 0) System.out.println("No faculty entered.");
        else for (int i = 0; i < facCount; i++) { faculty[i].display(); System.out.println(); }

        System.out.println("========== STUDENTS ==========");
        if (stuCount == 0) System.out.println("No students entered.");
        else for (int i = 0; i < stuCount; i++) { students[i].display(); System.out.println(); }

        sc.close();
    }
}
