public class LabCourse extends CollegeCourse {
    private static final double LAB_FEE = 50.0;

    public LabCourse(String department, int courseNumber, int credits) {
        super(department, courseNumber, credits);
    }

    @Override
    public double getFee() {
        return super.getFee() + LAB_FEE;
    }

    @Override
    public void display() {
        System.out.printf("[LAB COURSE] Department: %s | Course: %d | Credits: %d | Fee: $%.2f (includes $%.2f lab fee)%n",
                getDepartment(), getCourseNumber(), getCredits(), getFee(), LAB_FEE);
    }
}
