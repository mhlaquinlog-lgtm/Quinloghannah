public class DemoPoems {
    public static void main(String[] args) {
        Poem p      = new Poem("Ode to Spring", 14);
        Couplet c   = new Couplet("Two Lines of Thought");
        Limerick l  = new Limerick("The Man from Nantucket");
        Haiku h     = new Haiku("Silent Pond");

        System.out.println(p);
        System.out.println(c);
        System.out.println(l);
        System.out.println(h);

        // Demonstrate get methods
        System.out.println("\nHaiku title: " + h.getName());
        System.out.println("Haiku lines: " + h.getLines());
    }
}
