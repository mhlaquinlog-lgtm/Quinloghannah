public class Candle {
    private String color;
    private int height;
    private double price;

    public Candle(String color, int height) {
        this.color = color;
        setHeight(height);
    }

    public String getColor()  { return color; }
    public int getHeight()    { return height; }
    public double getPrice()  { return price; }

    public void setColor(String color) { this.color = color; }

    public void setHeight(int height) {
        this.height = height;
        this.price  = height * 2.0;
    }

    @Override
    public String toString() {
        return String.format("Candle [Color: %s, Height: %d in, Price: $%.2f]",
                color, height, price);
    }
}
