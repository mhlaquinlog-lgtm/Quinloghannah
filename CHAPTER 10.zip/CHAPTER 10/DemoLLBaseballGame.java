public class DemoLLBaseballGame {
    public static void main(String[] args) {
        LittleLeagueBaseballGame game = new LittleLeagueBaseballGame("Cubs", "Sox");

        int[] c = {1, 2, 0, 0, 1, 0};
        int[] s = {0, 0, 3, 1, 0, 2};
        for (int i = 0; i < 6; i++) {
            game.setScore1(c[i], i);
            game.setScore2(s[i], i);
        }

        game.displayScores();
        System.out.println("Result: " + game.determineWinner());

        // Demonstrate locked innings
        System.out.println("\nTrying to set inning 7 (doesn't exist in LL game):");
        game.setScore1(4, 6); // Error
    }
}
