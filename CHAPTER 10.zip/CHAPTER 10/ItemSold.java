public class ItemSold {
    private int invoiceNumber;
    private String description;
    private double price;

    public ItemSold(int invoiceNumber, String description, double price) {
        this.invoiceNumber = invoiceNumber;
        this.description   = description;
        this.price         = price;
    }

    public int getInvoiceNumber()          { return invoiceNumber; }
    public String getDescription()         { return description; }
    public double getPrice()               { return price; }

    public void setInvoiceNumber(int n)    { this.invoiceNumber = n; }
    public void setDescription(String d)   { this.description = d; }
    public void setPrice(double p)         { this.price = p; }

    @Override
    public String toString() {
        return String.format("Invoice #%d | %s | $%.2f", invoiceNumber, description, price);
    }
}
