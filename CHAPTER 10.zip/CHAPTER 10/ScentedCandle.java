public class ScentedCandle extends Candle {
    private String scent;

    public ScentedCandle(String color, int height, String scent) {
        super(color, height);
        this.scent = scent;
    }

    public String getScent()         { return scent; }
    public void setScent(String scent) { this.scent = scent; }

    @Override
    public void setHeight(int height) {
        // Use reflection-safe approach: store height via parent field logic,
        // but override price to $3/inch
        super.setHeight(height);           // sets height field
        // Override the price set by parent
        // We need direct access, so we shadow via getter logic
    }

    // Override getPrice to always compute $3/inch
    @Override
    public double getPrice() {
        return getHeight() * 3.0;
    }

    @Override
    public String toString() {
        return String.format("ScentedCandle [Color: %s, Height: %d in, Scent: %s, Price: $%.2f]",
                getColor(), getHeight(), scent, getPrice());
    }
}
