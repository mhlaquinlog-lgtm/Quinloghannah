public class Rock {
    private int    sampleNumber;
    private String description;
    private double weight; // grams

    public Rock(int sampleNumber, double weight) {
        this.sampleNumber = sampleNumber;
        this.weight       = weight;
        this.description  = "Unclassified";
    }

    public int    getSampleNumber() { return sampleNumber; }
    public String getDescription()  { return description; }
    public double getWeight()       { return weight; }

    protected void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return String.format("Sample #%d | Type: %s | Weight: %.2f g",
                sampleNumber, description, weight);
    }
}
