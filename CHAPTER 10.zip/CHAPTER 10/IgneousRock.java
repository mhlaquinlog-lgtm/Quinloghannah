public class IgneousRock extends Rock {
    public IgneousRock(int sampleNumber, double weight) {
        super(sampleNumber, weight);
        setDescription("Igneous - formed from cooled magma or lava; typically crystalline in structure (e.g., granite, basalt).");
    }
}
