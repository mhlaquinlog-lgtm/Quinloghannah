import java.util.Scanner;

public class Person {
    private String firstName;
    private String lastName;
    private String streetAddress;
    private String zipCode;
    private String phoneNumber;

    public Person() {}

    public Person(String firstName, String lastName, String streetAddress,
                  String zipCode, String phoneNumber) {
        this.firstName     = firstName;
        this.lastName      = lastName;
        this.streetAddress = streetAddress;
        this.zipCode       = zipCode;
        this.phoneNumber   = phoneNumber;
    }

    public String getFirstName()     { return firstName; }
    public String getLastName()      { return lastName; }
    public String getStreetAddress() { return streetAddress; }
    public String getZipCode()       { return zipCode; }
    public String getPhoneNumber()   { return phoneNumber; }

    public void setFirstName(String s)     { firstName = s; }
    public void setLastName(String s)      { lastName = s; }
    public void setStreetAddress(String s) { streetAddress = s; }
    public void setZipCode(String s)       { zipCode = s; }
    public void setPhoneNumber(String s)   { phoneNumber = s; }

    public void inputData(Scanner sc) {
        System.out.print("  First Name: ");     firstName     = sc.nextLine().trim();
        System.out.print("  Last Name: ");      lastName      = sc.nextLine().trim();
        System.out.print("  Street Address: "); streetAddress = sc.nextLine().trim();
        System.out.print("  Zip Code: ");       zipCode       = sc.nextLine().trim();
        System.out.print("  Phone Number: ");   phoneNumber   = sc.nextLine().trim();
    }

    public void display() {
        System.out.println(firstName + " " + lastName + " | " + streetAddress +
                           " | Zip: " + zipCode + " | Phone: " + phoneNumber);
    }
}
