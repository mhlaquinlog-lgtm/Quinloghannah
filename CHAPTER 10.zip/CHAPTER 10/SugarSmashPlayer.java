public class SugarSmashPlayer {
    protected static final int NUM_LEVELS = 10;
    protected static final int MIN_SCORE  = 100;

    private int    idNumber;
    private String screenName;
    protected int[] scores;

    public SugarSmashPlayer(int idNumber, String screenName) {
        this.idNumber   = idNumber;
        this.screenName = screenName;
        this.scores     = new int[NUM_LEVELS];
        // -1 means "not yet set"
        for (int i = 0; i < NUM_LEVELS; i++) scores[i] = -1;
    }

    public int    getIdNumber()   { return idNumber; }
    public String getScreenName() { return screenName; }

    public void setIdNumber(int id)          { this.idNumber = id; }
    public void setScreenName(String name)   { this.screenName = name; }

    public int getScore(int level) {
        if (!validLevel(level)) { System.out.println("Error: Level out of range."); return -1; }
        return scores[level];
    }

    public void setScore(int score, int level) {
        if (!validLevel(level)) { System.out.println("Error: Level out of range."); return; }
        if (level > 0) {
            for (int i = 0; i < level; i++) {
                if (scores[i] < MIN_SCORE) {
                    System.out.println("Error: Level " + (level + 1) +
                            " is not yet available. Complete all previous levels with at least 100 points.");
                    return;
                }
            }
        }
        scores[level] = score;
    }

    protected boolean validLevel(int level) {
        return level >= 0 && level < NUM_LEVELS;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ID: ").append(idNumber)
          .append(" | Screen Name: ").append(screenName)
          .append(" | Scores: ");
        for (int i = 0; i < NUM_LEVELS; i++) {
            sb.append("L").append(i + 1).append("=").append(scores[i] == -1 ? "N/A" : scores[i]);
            if (i < NUM_LEVELS - 1) sb.append(", ");
        }
        return sb.toString();
    }
}
