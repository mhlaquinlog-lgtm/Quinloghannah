import java.util.Scanner;

public class TestLease {

    public static void main(String[] args) {

        Lease l1 = getData();
        Lease l2 = getData();
        Lease l3 = getData();
        Lease l4 = new Lease();

        showValues(l1);
        l1.addPetFee();
        showValues(l1);

        showValues(l2);
        showValues(l3);
        showValues(l4);
    }

    public static Lease getData() {
        Scanner input = new Scanner(System.in);
        Lease lease = new Lease();

        System.out.print("Enter name: ");
        lease.setName(input.nextLine());

        System.out.print("Enter apartment number: ");
        lease.setAptNumber(input.nextInt());

        System.out.print("Enter rent: ");
        lease.setRent(input.nextDouble());

        System.out.print("Enter term: ");
        lease.setTerm(input.nextInt());
        input.nextLine();

        return lease;
    }

    public static void showValues(Lease l) {
        System.out.println(l.getName() + " " +
                l.getAptNumber() + " " +
                l.getRent() + " " +
                l.getTerm());
    }
}
