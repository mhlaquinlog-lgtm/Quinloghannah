import java.util.Scanner;

public class CraftPricing {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter product name: ");
        String name = input.nextLine();

        System.out.print("Enter material cost: ");
        double cost = input.nextDouble();

        System.out.print("Enter hours of work: ");
        double hours = input.nextDouble();

        double price = computePrice(cost, hours);
        System.out.println(name + " price is $" + price);
    }

    public static double computePrice(double material, double hours) {
        return material + (12 * hours) + 7;
    }
}
