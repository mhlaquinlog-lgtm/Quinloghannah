import java.util.Scanner;

public class Percentages2 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter first number: ");
        double num1 = input.nextDouble();

        System.out.print("Enter second number: ");
        double num2 = input.nextDouble();

        computePercent(num1, num2);
        computePercent(num2, num1);
    }

    public static void computePercent(double first, double second) {
        double percent = (first / second) * 100;
        System.out.println(first + " is " + percent + " percent of " + second);
    }
}
