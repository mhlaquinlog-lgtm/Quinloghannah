public class ShowStudent2 {

    public static void main(String[] args) {
        Student s = new Student();
        s.display();
    }


    private int id;
    private int creditHours;
    private int points;
    private double gpa;

    public Student() {
        id = 9999;
        creditHours = 3;
        points = 12;
        computeGPA();
    }

    public void computeGPA() {
        gpa = (double) points / creditHours;
    }

    public void display() {
        System.out.println(id + " " + creditHours + " " + points + " " + gpa);
    }
}
