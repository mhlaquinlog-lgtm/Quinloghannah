public class Student {

    private int id;
    private int creditHours;
    private int points;
    private double gpa;

    public void setValues(int id, int creditHours, int points) {
        this.id = id;
        this.creditHours = creditHours;
        this.points = points;
    }

    public void computeGPA() {
        gpa = (double) points / creditHours;
    }

    public void display() {
        System.out.println("ID: " + id);
        System.out.println("Credits: " + creditHours);
        System.out.println("Points: " + points);
        System.out.println("GPA: " + gpa);
    }
}
