import java.util.Scanner;

public class Insurance {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter current year: ");
        int currentYear = input.nextInt();

        System.out.print("Enter birth year: ");
        int birthYear = input.nextInt();

        int premium = calculatePremium(currentYear, birthYear);
        System.out.println("Premium is $" + premium);
    }

    public static int calculatePremium(int current, int birth) {
        int age = current - birth;
        int decade = age / 10;
        return (decade + 15) * 20;
    }
}
