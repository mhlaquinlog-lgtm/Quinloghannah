public class Sandwich {

    private String ingredient;
    private String breadType;
    private double price;

    public void setIngredient(String ingredient) {
        this.ingredient = ingredient;
    }

    public void setBreadType(String breadType) {
        this.breadType = breadType;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getIngredient() {
        return ingredient;
    }

    public String getBreadType() {
        return breadType;
    }

    public double getPrice() {
        return price;
    }
}
