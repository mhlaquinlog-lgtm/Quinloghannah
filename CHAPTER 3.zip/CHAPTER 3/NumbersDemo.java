public class NumbersDemo {

    public static void main(String[] args) {
        int num1 = 4;
        int num2 = 7;

        displayTwiceTheNumber(num1);
        displayNumberPlusFive(num1);
        displayNumberSquared(num1);

        displayTwiceTheNumber(num2);
        displayNumberPlusFive(num2);
        displayNumberSquared(num2);
    }

    public static void displayTwiceTheNumber(int num) {
        System.out.println(num + " doubled is " + (num * 2));
    }

    public static void displayNumberPlusFive(int num) {
        System.out.println(num + " plus five is " + (num + 5));
    }

    public static void displayNumberSquared(int num) {
        System.out.println(num + " squared is " + (num * num));
    }
}
