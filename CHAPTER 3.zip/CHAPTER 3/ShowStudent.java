public class ShowStudent {

    public static void main(String[] args) {

        Student s = new Student();
        s.setValues(1234, 6, 18);
        s.computeGPA();
        s.display();
    }
}
