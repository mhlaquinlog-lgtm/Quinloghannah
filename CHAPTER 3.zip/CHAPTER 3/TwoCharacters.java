public class TwoCharacters {

    public static void main(String[] args) {

        MyCharacter c1 = new MyCharacter();
        MyCharacter c2 = new MyCharacter();

        c1.setColor("Green");
        c1.setEyes(3);
        c1.setLives(2);

        c2.setColor("Blue");
        c2.setEyes(4);
        c2.setLives(5);

        display(c1);
        display(c2);
    }

    public static void display(MyCharacter c){
        System.out.println(c.getColor()+" "+c.getEyes()+" "+c.getLives());
    }
}
