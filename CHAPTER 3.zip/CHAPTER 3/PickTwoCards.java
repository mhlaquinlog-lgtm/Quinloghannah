public class PickTwoCards {

    public static void main(String[] args) {

        final int CARDS_IN_SUIT = 13;

        Card c1 = new Card();
        Card c2 = new Card();

        c1.setSuit('s');
        c2.setSuit('h');

        c1.setValue((int)(Math.random()*100) % CARDS_IN_SUIT + 1);
        c2.setValue((int)(Math.random()*100) % CARDS_IN_SUIT + 1);

        System.out.println("Card1: " + c1.getSuit() + " " + c1.getValue());
        System.out.println("Card2: " + c2.getSuit() + " " + c2.getValue());
    }
}
