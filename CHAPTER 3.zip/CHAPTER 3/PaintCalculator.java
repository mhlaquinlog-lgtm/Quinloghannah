import java.util.Scanner;

public class PaintCalculator {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter room length: ");
        double length = input.nextDouble();

        System.out.print("Enter room width: ");
        double width = input.nextDouble();

        System.out.print("Enter room height: ");
        double height = input.nextDouble();

        double price = calculatePaint(length, width, height);
        System.out.println("Total paint cost: $" + price);
    }

    public static double calculatePaint(double l, double w, double h) {
        double wallArea = 2 * (l * h + w * h);
        double gallons = wallArea / 350;
        double price = gallons * 32;

        System.out.println("Gallons needed: " + gallons);
        return price;
    }
}
