import java.util.Scanner;

public class MetricConversion {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter an integer value: ");
        int value = input.nextInt();

        inchesToCentimeters(value);
        gallonsToLiters(value);
    }

    public static void inchesToCentimeters(int inches) {
        double cm = inches * 2.54;
        System.out.println(inches + " inches is " + cm + " centimeters.");
    }

    public static void gallonsToLiters(int gallons) {
        double liters = gallons * 3.7854;
        System.out.println(gallons + " gallons is " + liters + " liters.");
    }
}
