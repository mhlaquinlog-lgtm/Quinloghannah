public class Lease {

    private String name;
    private int aptNumber;
    private double rent;
    private int term;

    public Lease() {
        name = "XXX";
        aptNumber = 0;
        rent = 1000;
        term = 12;
    }

    public void setName(String n) { name = n; }
    public void setAptNumber(int a) { aptNumber = a; }
    public void setRent(double r) { rent = r; }
    public void setTerm(int t) { term = t; }

    public String getName() { return name; }
    public int getAptNumber() { return aptNumber; }
    public double getRent() { return rent; }
    public int getTerm() { return term; }

    public void addPetFee() {
        rent += 10;
        explainPetPolicy();
    }

    public static void explainPetPolicy() {
        System.out.println("Pet fee adds $10 to monthly rent.");
    }
}
