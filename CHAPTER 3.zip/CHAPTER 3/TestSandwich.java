public class TestSandwich {

    public static void main(String[] args) {

        Sandwich s = new Sandwich();

        s.setIngredient("Tuna");
        s.setBreadType("Wheat");
        s.setPrice(4.99);

        System.out.println(s.getIngredient());
        System.out.println(s.getBreadType());
        System.out.println(s.getPrice());
    }
}
