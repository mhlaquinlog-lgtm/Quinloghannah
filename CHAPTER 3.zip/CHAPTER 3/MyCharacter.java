public class MyCharacter {

    private String color;
    private int eyes;
    private int lives;

    public void setColor(String c){ color = c; }
    public void setEyes(int e){ eyes = e; }
    public void setLives(int l){ lives = l; }

    public String getColor(){ return color; }
    public int getEyes(){ return eyes; }
    public int getLives(){ return lives; }
}
