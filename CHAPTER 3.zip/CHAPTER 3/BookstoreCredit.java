import java.util.Scanner;

public class BookstoreCredit {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter student name: ");
        String name = input.nextLine();

        System.out.print("Enter GPA: ");
        double gpa = input.nextDouble();

        displayCredit(name, gpa);
    }

    public static void displayCredit(String name, double gpa) {
        double credit = gpa * 10;
        System.out.println(name + " has GPA " + gpa +
                " and receives bookstore credit of $" + credit);
    }
}
