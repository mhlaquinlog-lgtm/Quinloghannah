import java.util.Scanner;

public class NumbersDemo2 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter first integer: ");
        int num1 = input.nextInt();

        System.out.print("Enter second integer: ");
        int num2 = input.nextInt();

        displayTwiceTheNumber(num1);
        displayNumberPlusFive(num1);
        displayNumberSquared(num1);

        displayTwiceTheNumber(num2);
        displayNumberPlusFive(num2);
        displayNumberSquared(num2);
    }

    public static void displayTwiceTheNumber(int num) {
        System.out.println(num * 2);
    }

    public static void displayNumberPlusFive(int num) {
        System.out.println(num + 5);
    }

    public static void displayNumberSquared(int num) {
        System.out.println(num * num);
    }
}
