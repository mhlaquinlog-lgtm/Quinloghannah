import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class SubarraySumConstraint {
    public static void main(String[] args) throws Exception {

        String jsCode = ""
            + "const fs = require('fs');"
            + "const input = fs.readFileSync(0, 'utf-8').trim().split('\\n');"

            + "const [N, S, L] = input[0].split(' ').map(Number);"
            + "const arr = input[1].split(' ').map(Number);"

            + "let count = 0;"

            + "for (let i = 0; i < N; i++) {"
            + "    let sum = 0;"
            + "    for (let j = i; j < N; j++) {"
            + "        sum += arr[j];"
            + "        let len = j - i + 1;"

            + "        if (len >= L && sum <= S) {"
            + "            count++;"
            + "        }"
            + "    }"
            + "}"

            + "console.log(count);";

        ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
        engine.eval(jsCode);
    }
}