import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class VowelOrConsonant {
    public static void main(String[] args) throws Exception {
        
        String jsCode = ""
            + "const fs = require('fs');"
            + "let ch = fs.readFileSync(0, 'utf-8').trim();"
            + "ch = ch.toLowerCase();"
            + "if ('aeiou'.includes(ch)) {"
            + "    console.log('Vowel');"
            + "} else {"
            + "    console.log('Consonant');"
            + "}";

        ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
        engine.eval(jsCode);
    }
}