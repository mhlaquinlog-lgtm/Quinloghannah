import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class MinimalSubarrayLength {
    public static void main(String[] args) throws Exception {

        String jsCode = ""
            + "function minimalSubarrayLength(arr, S) {"
            + "    let n = arr.length;"
            + "    let left = 0;"
            + "    let sum = 0;"
            + "    let minLen = Infinity;"
            + "    for (let right = 0; right < n; right++) {"
            + "        sum += arr[right];"
            + "        while (sum >= S) {"
            + "            minLen = Math.min(minLen, right - left + 1);"
            + "            sum -= arr[left];"
            + "            left++;"
            + "        }"
            + "    }"
            + "    return minLen === Infinity ? 0 : minLen;"
            + "}"

            + "print(minimalSubarrayLength([2,3,1,2,4,3,8], 15));";

        ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
        engine.eval(jsCode);
    }
}