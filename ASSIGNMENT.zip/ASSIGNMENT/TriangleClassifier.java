import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class TriangleClassifier {
    public static void main(String[] args) throws Exception {

        String jsCode = ""
            + "const fs = require('fs');"
            + "const input = fs.readFileSync(0, 'utf-8').trim().split(' ').map(Number);"
            + "let [a, b, c] = input;"
            + "if (a + b <= c || a + c <= b || b + c <= a) {"
            + "    console.log('Invalid');"
            + "} "
            + "else if (a === b && b === c) {"
            + "    console.log('Equilateral');"
            + "} "
            + "else if (a === b || b === c || a === c) {"
            + "    console.log('Isosceles');"
            + "} "
            + "else {"
            + "    console.log('Scalene');"
            + "}";

        ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
        engine.eval(jsCode);
    }
}