import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class SlidingWindowTolerance {
    public static void main(String[] args) throws Exception {

        String jsCode = ""
            + "function countValidWindows(w, t, arr) {"
            + "    let count = 0;"
            + "    for (let i = 0; i <= arr.length - w; i++) {"
            + "        let window = arr.slice(i, i + w);"
            + "        let max = Math.max(...window);"
            + "        let min = Math.min(...window);"
            + "        if (max - min <= t) {"
            + "            count++;"
            + "        }"
            + "    }"
            + "    return count;"
            + "}"

            + "let w = 4;"
            + "let t = 5;"
            + "let data = [10, 12, 11, 15, 16, 14, 20, 21, 22];"

            + "print('Valid Windows: ' + countValidWindows(w, t, data));";

        ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
        engine.eval(jsCode);
    }
}