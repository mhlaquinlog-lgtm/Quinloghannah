import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class TokenValueMaximizer {
    public static void main(String[] args) throws Exception {

        String jsCode = ""
            + "function tokenValueMaximizer(S, D) {"
            + "    const delimiters = new Set(D.split(''));"
            + "    const vowels = new Set(['a','e','i','o','u']);"

            + "    let tokens = [];"
            + "    let current = '';"

            + "    for (let char of S) {"
            + "        if (delimiters.has(char)) {"
            + "            if (current.length > 0) tokens.push(current);"
            + "            current = '';"
            + "        } else {"
            + "            current += char;"
            + "        }"
            + "    }"
            + "    if (current.length > 0) tokens.push(current);"

            + "    function getValue(token) {"
            + "        let value = 0;"
            + "        for (let ch of token) {"
            + "            if (/[a-zA-Z]/.test(ch)) {"
            + "                if (vowels.has(ch.toLowerCase())) value += 2;"
            + "                else value += 1;"
            + "            } else if (/[0-9]/.test(ch)) {"
            + "                value += parseInt(ch);"
            + "            }"
            + "        }"
            + "        return value;"
            + "    }"

            + "    let maxToken = '';"
            + "    let maxValue = -1;"

            + "    for (let token of tokens) {"
            + "        let val = getValue(token);"
            + "        if (val > maxValue) {"
            + "            maxValue = val;"
            + "            maxToken = token;"
            + "        }"
            + "    }"

            + "    return maxToken;"
            + "}"

            + "print(tokenValueMaximizer('hello/world_123', '/_'));";

        ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
        engine.eval(jsCode);
    }
}