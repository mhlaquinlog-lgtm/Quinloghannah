import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class VowelConsonantBalance {
    public static void main(String[] args) throws Exception {

        String jsCode = ""
            + "const fs = require('fs');"
            + "const S = fs.readFileSync(0, 'utf-8').trim();"

            + "function isVowel(c) {"
            + "    return 'AEIOU'.includes(c);"
            + "}"

            + "function longestBalancedSubstring(s) {"
            + "    let map = new Map();"
            + "    let sum = 0;"
            + "    let maxLen = 0;"
            + "    map.set(0, -1);"

            + "    for (let i = 0; i < s.length; i++) {"
            + "        if (isVowel(s[i])) sum += 1;"
            + "        else sum -= 1;"

            + "        if (map.has(sum)) {"
            + "            let len = i - map.get(sum);"
            + "            maxLen = Math.max(maxLen, len);"
            + "        } else {"
            + "            map.set(sum, i);"
            + "        }"
            + "    }"

            + "    return maxLen;"
            + "}"

            + "console.log(longestBalancedSubstring(S));";

        ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
        engine.eval(jsCode);
    }
}