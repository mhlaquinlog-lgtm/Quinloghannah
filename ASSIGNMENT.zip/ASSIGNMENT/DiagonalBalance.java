import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class DiagonalBalance {
    public static void main(String[] args) throws Exception {

        String jsCode = ""
            + "function diagonalBalance(matrix) {"
            + "    const n = matrix.length;"

            + "    function getSums(mat) {"
            + "        let main = 0, anti = 0;"
            + "        for (let i = 0; i < n; i++) {"
            + "            main += mat[i][i];"
            + "            anti += mat[i][n - i - 1];"
            + "        }"
            + "        return [main, anti];"
            + "    }"

            + "    let [main, anti] = getSums(matrix);"
            + "    if (main === anti) return '-1 -1';"

            + "    for (let i = 0; i < n; i++) {"
            + "        let newMatrix = matrix.map(row => [...row]);"
            + "        for (let j = 0; j < n; j++) {"
            + "            newMatrix[i][j] *= -1;"
            + "        }"
            + "        let [m, a] = getSums(newMatrix);"
            + "        if (m === a) return 'R ' + i;"
            + "    }"

            + "    for (let j = 0; j < n; j++) {"
            + "        let newMatrix = matrix.map(row => [...row]);"
            + "        for (let i = 0; i < n; i++) {"
            + "            newMatrix[i][j] *= -1;"
            + "        }"
            + "        let [m, a] = getSums(newMatrix);"
            + "        if (m === a) return 'C ' + j;"
            + "    }"

            + "    return 'IMPOSSIBLE';"
            + "}"

            + "let mat = ["
            + "    [5,0,2],"
            + "    [0,0,0],"
            + "    [1,0,4]"
            + "];"

            + "print(diagonalBalance(mat));";

        ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
        engine.eval(jsCode);
    }
}