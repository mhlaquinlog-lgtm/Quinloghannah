import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class ConsecutivePlateaus {
    public static void main(String[] args) throws Exception {

        String jsCode = ""
            + "function countPlateaus(arr) {"
            + "    let count = 0;"
            + "    let i = 0;"
            + "    while (i < arr.length) {"
            + "        let j = i;"
            + "        while (j + 1 < arr.length && arr[j] === arr[j + 1]) {"
            + "            j++;"
            + "        }"
            + "        if (j > i) {"
            + "            count++;"
            + "        }"
            + "        i = j + 1;"
            + "    }"
            + "    return count;"
            + "}"

            + "let sequence = [1, 2, 2, 3, 3, 3, 4, 5, 5];"

            + "print('Plateau count: ' + countPlateaus(sequence));";

        ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
        engine.eval(jsCode);
    }
}