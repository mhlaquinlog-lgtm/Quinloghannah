import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class SubsequenceEndIndex {
    public static void main(String[] args) throws Exception {

        String jsCode = ""
            + "function subsequenceEndIndex(S, T) {"
            + "    let j = 0;"
            + "    for (let i = 0; i < S.length; i++) {"
            + "        if (S[i] === T[j]) {"
            + "            j++;"
            + "        }"
            + "        if (j === T.length) {"
            + "            return i;"
            + "        }"
            + "    }"
            + "    return -1;"
            + "}"

            + "print(subsequenceEndIndex('programming', 'pro'));"
            + "print(subsequenceEndIndex('abacabadabacaba', 'ace'));"
            + "print(subsequenceEndIndex('banana', 'bna'));";

        ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
        engine.eval(jsCode);
    }
}