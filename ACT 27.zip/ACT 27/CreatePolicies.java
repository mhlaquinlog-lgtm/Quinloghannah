public class CreatePolicies
{
    public static void main(String[] args)
    {
        CarInsurancePolicy first = new CarInsurancePolicy(123);
        CarInsurancePolicy second = new CarInsurancePolicy(456, 4);
        CarInsurancePolicy third = new CarInsurancePolicy(789, 12, "Newcastle");

        first.display();
        second.display();
        third.display();

        // This will cause a compile-time error because
        // CarInsurancePolicy has NO default constructor
        // CarInsurancePolicy fourth = new CarInsurancePolicy();
    }
}