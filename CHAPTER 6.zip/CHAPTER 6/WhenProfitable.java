public class WhenProfitable {
    public static void main(String[] args) {

        double gross = 20000;
        double expenses = 35000;
        boolean profitable = false;

        for(int year = 1; year <= 20; year++) {

            double net = gross - expenses;

            System.out.printf("Year %d | Gross: %.2f | Expenses: %.2f | Net: %.2f%n",
                    year, gross, expenses, net);

            if(net > 0 && !profitable) {
                System.out.println("First profitable year: " + year);
                profitable = true;
            }

            gross *= 1.10;
            expenses *= 1.04;
        }
    }
}