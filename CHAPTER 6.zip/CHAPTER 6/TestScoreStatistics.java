import java.util.Scanner;

public class TestScoreStatistics {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int count = 0;
        int highest = Integer.MIN_VALUE;
        int lowest = Integer.MAX_VALUE;
        int total = 0;
        int score;

        while(true) {
            System.out.print("Enter score (999 to stop): ");
            score = input.nextInt();

            if(score == 999)
                break;

            if(score < 0 || score > 100) {
                System.out.println("Invalid score.");
                continue;
            }

            count++;
            total += score;
            if(score > highest) highest = score;
            if(score < lowest) lowest = score;
        }

        if(count == 0)
            System.out.println("No valid scores entered.");
        else {
            System.out.println("Number of scores: " + count);
            System.out.println("Highest: " + highest);
            System.out.println("Lowest: " + lowest);
            System.out.println("Average: " + (total / (double)count));
        }
    }
}