import java.util.Scanner;

public class Quiz2 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String question = "Which planet is known as the Red Planet?\nA. Earth\nB. Mars\nC. Venus\nD. Jupiter";
        char correctAnswer = 'B';
        char user;

        do {
            System.out.println(question);
            System.out.print("Answer: ");
            user = Character.toUpperCase(input.next().charAt(0));

            if(user != correctAnswer)
                System.out.println("Incorrect. Try again.\n");

        } while(user != correctAnswer);

        System.out.println("Correct!");
    }
}