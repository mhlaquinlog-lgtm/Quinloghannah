public class Purchase {
    private int invoiceNumber;
    private double saleAmount;
    private double salesTax;

    public void setInvoiceNumber(int num) {
        invoiceNumber = num;
    }

    public void setSaleAmount(double amount) {
        saleAmount = amount;
        salesTax = saleAmount * 0.05;
    }

    public void display() {
        System.out.println("Invoice: " + invoiceNumber);
        System.out.println("Sale Amount: $" + saleAmount);
        System.out.println("Sales Tax: $" + salesTax);
    }
}