import java.util.Scanner;

public class TwoDice3 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Choose number (2-12): ");
        int choice = input.nextInt();

        for(int i = 1; i <= 3; i++) {
            int die1 = 1 + (int)(Math.random() * 6);
            int die2 = 1 + (int)(Math.random() * 6);
            int total = die1 + die2;

            System.out.println("Roll " + i + ": " + total);

            if(total == choice) {
                System.out.println("You win!");
                return;
            }
        }

        System.out.println("Computer wins!");
    }
}