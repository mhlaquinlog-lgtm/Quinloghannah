import java.util.Scanner;

public class RandomGuess3 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int random = 1 + (int)(Math.random() * 100);
        int guess;
        int attempts = 0;

        do {
            System.out.print("Guess (1-100): ");
            guess = input.nextInt();
            attempts++;

            if(guess > random)
                System.out.println("Too high");
            else if(guess < random)
                System.out.println("Too low");

        } while(guess != random);

        System.out.println("Correct! Attempts: " + attempts);
    }
}