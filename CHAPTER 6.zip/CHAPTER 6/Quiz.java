import java.util.Scanner;

public class Quiz {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String[] questions = {
            "1. Which planet is known as the Red Planet?\nA. Earth\nB. Mars\nC. Venus\nD. Jupiter",
            "2. How many continents are there?\nA. 5\nB. 6\nC. 7\nD. 8",
            "3. What is the chemical symbol for Gold?\nA. Au\nB. Ag\nC. Go\nD. Gd",
            "4. Which ocean is the largest?\nA. Atlantic\nB. Indian\nC. Arctic\nD. Pacific",
            "5. What is 9 x 9?\nA. 72\nB. 81\nC. 99\nD. 90"
        };

        char[] answers = {'B','C','A','D','B'};
        int correct = 0;

        for(int i = 0; i < questions.length; i++) {
            System.out.println(questions[i]);
            System.out.print("Answer: ");
            char user = Character.toUpperCase(input.next().charAt(0));

            if(user == answers[i]) {
                System.out.println("Correct!\n");
                correct++;
            } else {
                System.out.println("Incorrect! Correct answer is " + answers[i] + "\n");
            }
        }

        System.out.println("Correct: " + correct);
        System.out.println("Incorrect: " + (questions.length - correct));
        System.out.println("Percentage: " + (correct * 100 / questions.length) + "%");
    }
}