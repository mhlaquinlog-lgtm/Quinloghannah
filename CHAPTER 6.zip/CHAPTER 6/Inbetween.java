import java.util.Scanner;

public class Inbetween {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter first integer: ");
        int a = input.nextInt();

        System.out.print("Enter second integer: ");
        int b = input.nextInt();

        int min = Math.min(a, b);
        int max = Math.max(a, b);

        if(max - min <= 1)
            System.out.println("No integers between.");
        else {
            for(int i = min + 1; i < max; i++)
                System.out.print(i + " ");
        }
    }
}