import java.util.Scanner;

public class BarChart {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        String[] players = {"Art", "Bob", "Cal", "Dan", "Eli"};
        int[] scores = new int[5];

        for(int i = 0; i < 5; i++) {
            System.out.print("Enter points for " + players[i] + ": ");
            scores[i] = input.nextInt();
        }

        for(int i = 0; i < 5; i++) {
            System.out.print(players[i] + ": ");
            for(int j = 0; j < scores[i]; j++)
                System.out.print("*");
            System.out.println();
        }
    }
}