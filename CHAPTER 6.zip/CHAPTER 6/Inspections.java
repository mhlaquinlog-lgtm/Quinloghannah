public class Inspections {
    public static void main(String[] args) {

        int[] factories = new int[4];

        for(int week = 1; week <= 52; week++) {
            int factory = 1 + (int)(Math.random() * 4);
            factories[factory - 1]++;
            System.out.println("Week " + week + ": Inspect Factory " + factory);
        }

        System.out.println("\nInspection percentages:");
        for(int i = 0; i < 4; i++) {
            System.out.printf("Factory %d: %.2f%%%n",
                    i + 1, (factories[i] / 52.0) * 100);
        }
    }
}