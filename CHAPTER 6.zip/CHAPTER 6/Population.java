public class Population {
    public static void main(String[] args) {

        double mexico = 121_000_000;
        double us = 315_000_000;
        int years = 0;

        while(mexico <= us) {
            mexico *= 1.0101;
            us *= 0.9985;
            years++;
        }

        System.out.println("Mexico exceeds US after " + years + " years.");
    }
}