import java.util.Scanner;

public class CreatePurchase {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Purchase p = new Purchase();

        int invoice;
        double amount;

        do {
            System.out.print("Enter invoice number (1000-8000): ");
            invoice = input.nextInt();
        } while(invoice < 1000 || invoice > 8000);

        do {
            System.out.print("Enter sale amount: ");
            amount = input.nextDouble();
        } while(amount < 0);

        p.setInvoiceNumber(invoice);
        p.setSaleAmount(amount);
        p.display();
    }
}