import java.util.Scanner;

public class CountByAnything {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter value to count by: ");
        int value = input.nextInt();

        int count = 0;

        for(int i = value; i <= 300; i += value) {
            System.out.print(i + " ");
            count++;
            if(count % 10 == 0)
                System.out.println();
        }
    }
}