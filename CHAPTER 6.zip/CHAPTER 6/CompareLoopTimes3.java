import java.time.*;

public class CompareLoopTimes3 {
    public static void main(String[] args) {

        final int REPEAT = 100_000;

        long startTime = System.nanoTime();

        for(int x = 0; x <= REPEAT; ++x)
            for(int y = 0; y <= REPEAT; ++y);

        long endTime = System.nanoTime();

        System.out.println("Time for loops starting from 0: "
                + (endTime - startTime) / 1_000_000 + " ms");

        startTime = System.nanoTime();

        for(int x = REPEAT; x >= 0; --x)
            for(int y = REPEAT; y >= 0; --y);

        endTime = System.nanoTime();

        System.out.println("Time for loops ending with 0: "
                + (endTime - startTime) / 1_000_000 + " ms");
    }
}