import java.util.Scanner;

public class RetirementGoal {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int years;
        double annual;

        do {
            System.out.print("Years until retirement: ");
            years = input.nextInt();
        } while(years <= 0);

        do {
            System.out.print("Amount saved per year: ");
            annual = input.nextDouble();
        } while(annual <= 0);

        System.out.println("Total savings: $" + (years * annual));
    }
}