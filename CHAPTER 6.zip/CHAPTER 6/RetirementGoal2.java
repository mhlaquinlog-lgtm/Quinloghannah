import java.util.Scanner;

public class RetirementGoal2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int years;
        double annual;

        do {
            System.out.print("Years until retirement: ");
            years = input.nextInt();
        } while(years <= 0);

        do {
            System.out.print("Amount saved per year: ");
            annual = input.nextDouble();
        } while(annual <= 0);

        double balance = 0;

        for(int i = 1; i <= years; i++) {
            balance += annual;
            balance *= 1.05;
        }

        System.out.printf("Total savings with 5%% interest: $%.2f%n", balance);
    }
}