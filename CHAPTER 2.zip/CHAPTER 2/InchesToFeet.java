public class InchesToFeet {
    public static void main(String[] args) {

        final int INCHES_PER_FOOT = 12;
        int inches = 86;

        int feet = inches / INCHES_PER_FOOT;
        int remainingInches = inches % INCHES_PER_FOOT;

        System.out.println(inches + " inches equals "
                + feet + " feet and " + remainingInches + " inches.");
    }
}