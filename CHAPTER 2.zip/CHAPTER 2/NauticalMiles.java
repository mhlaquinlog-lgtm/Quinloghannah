public class NauticalMiles {
    public static void main(String[] args) {

        final double KM = 1.852;
        final double MILES = 1.150779;

        int nauticalMiles = 5;

        System.out.println(nauticalMiles + " nautical miles is "
                + (nauticalMiles * KM) + " kilometers and "
                + (nauticalMiles * MILES) + " miles.");
    }
}