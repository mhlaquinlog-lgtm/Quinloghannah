import java.util.Scanner;

public class QuartsToGallonsInteractive {
    public static void main(String[] args) {

        final int QUARTS_PER_GALLON = 4;
        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of quarts: ");
        int quarts = input.nextInt();

        int gallons = quarts / QUARTS_PER_GALLON;
        int remainingQuarts = quarts % QUARTS_PER_GALLON;

        System.out.println("That equals " + gallons + " gallons and "
                + remainingQuarts + " quarts.");
    }
}
