import java.util.Scanner;

public class ChiliToGo {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Adult meals: ");
        int adult = input.nextInt();

        System.out.print("Child meals: ");
        int child = input.nextInt();

        int total = (adult * 7) + (child * 4);

        System.out.println("Total money collected: $" + total);
    }
