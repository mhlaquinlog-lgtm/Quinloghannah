import java.util.Scanner;

public class ChiliToGoProfit {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Adult meals: ");
        int adult = input.nextInt();

        System.out.print("Child meals: ");
        int child = input.nextInt();

        int adultProfit = adult * (7 - 3.50);
        int childProfit = child * (4 - 3.10);

        double totalProfit = adultProfit + childProfit;

        System.out.println("Total profit: $" + totalProfit);
    }
}
