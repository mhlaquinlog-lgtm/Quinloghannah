public class QuartsToGallons {
    public static void main(String[] args) {

        final int QUARTS_PER_GALLON = 4;
        int quarts = 18;
        int gallons;
        int remainingQuarts;

        gallons = quarts / QUARTS_PER_GALLON;
        remainingQuarts = quarts % QUARTS_PER_GALLON;

        System.out.println("A job that needs " + quarts + " quarts requires "
                + gallons + " gallons plus " + remainingQuarts + " quarts.");
    }
}