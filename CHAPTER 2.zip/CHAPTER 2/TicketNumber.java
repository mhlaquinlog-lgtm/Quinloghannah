import java.util.Scanner;

public class TicketNumber {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter ticket number: ");
        int ticket = input.nextInt();

        int lastDigit = ticket % 10;
        int remaining = ticket / 10;

        boolean valid = (remaining % 7) == lastDigit;

        System.out.println("Ticket valid: " + valid);
    }
}
