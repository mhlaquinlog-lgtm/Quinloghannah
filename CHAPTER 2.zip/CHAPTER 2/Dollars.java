import java.util.Scanner;

public class Dollars {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter dollar amount: ");
        int dollars = input.nextInt();

        System.out.println("20s: " + dollars / 20);
        dollars %= 20;
        System.out.println("10s: " + dollars / 10);
        dollars %= 10;
        System.out.println("5s: " + dollars / 5);
        dollars %= 5;
        System.out.println("1s: " + dollars);
    }
}