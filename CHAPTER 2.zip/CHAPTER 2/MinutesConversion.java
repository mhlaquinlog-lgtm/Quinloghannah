import java.util.Scanner;

public class MinutesConversion {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter minutes: ");
        int minutes = input.nextInt();

        int hours = minutes / 60;
        double days = minutes / 1440.0;

        System.out.println(minutes + " minutes equals "
                + hours + " hours or " + days + " days.");
    }
}