public class Initials {
    public static void main(String[] args) {

        char first = 'H';
        char middle = 'A';
        char last = 'Q';

        System.out.println(first + "." + middle + "." + last + ".");
    }
}
