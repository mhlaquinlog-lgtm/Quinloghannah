import java.util.Scanner;

public class NauticalMilesInteractive {
    public static void main(String[] args) {

        final double KM = 1.852;
        final double MILES = 1.150779;

        Scanner input = new Scanner(System.in);

        System.out.print("Enter nautical miles: ");
        double nm = input.nextDouble();

        System.out.println(nm + " nautical miles is "
                + (nm * KM) + " kilometers and "
                + (nm * MILES) + " miles.");
    }
}