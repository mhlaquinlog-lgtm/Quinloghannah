import java.util.Scanner;

public class Eggs {
    public static void main(String[] args) {

        final double DOZEN_PRICE = 3.25;
        final double SINGLE_PRICE = 0.45;

        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of eggs: ");
        int eggs = input.nextInt();

        int dozens = eggs / 12;
        int singles = eggs % 12;

        double total = (dozens * DOZEN_PRICE) + (singles * SINGLE_PRICE);

        System.out.println("You ordered " + eggs + " eggs. That's "
                + dozens + " dozen and " + singles
                + " loose eggs for a total of $" + total);
    }
}